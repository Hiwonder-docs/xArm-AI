#include "esp32-hal.h"
#include "xArmController.h"

#define GET_LOW_BYTE(A) (uint8_t)((A))
//宏函数 获得A的低八位
#define GET_HIGH_BYTE(A) (uint8_t)((A) >> 8)
//宏函数 获得A的高八位
#define BYTE_TO_HW(A, B) ((((uint16_t)(A)) << 8) | (uint8_t)(B))
//宏函数 以A为高八位 B为低八位 合并为16位整形

xArmController::xArmController(){
  isRunning = false;
}

xArmController::xArmController(HardwareSerial &S){
  xArmController();
  SerialX = &S;
}

void xArmController::begin(){
  SerialX->begin(115200,SERIAL_8N1,rxPin,txPin);
  xTaskCreate( //创建数据接收线程
    receiveHandle,          
    "Task Receive",       
    1024,           
    this,           
    1,              
    NULL    
  );
}


/* 
  控制单个舵机转动
  servoID : 舵机ID
  Position : 舵机位置
  Time : 运行时间
*/
void xArmController::moveServo(uint8_t servoID, uint16_t Position, uint16_t Time){
  uint8_t buf[15];
  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 13;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
	buf[5] = FRAME_HEADER;                   //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 8;                              //数据长度=要控制舵机数*3+5，此处=1*3+5
	buf[8] = CMD_SERVO_MOVE;                 //填充舵机移动指令
	buf[9] = 1;                              //要控制的舵机个数
	buf[10] = GET_LOW_BYTE(Time);             //填充时间的低八位
	buf[11] = GET_HIGH_BYTE(Time);            //填充时间的高八位
	buf[12] = servoID;                        //舵机ID
	buf[13] = GET_LOW_BYTE(Position);         //填充目标位置的低八位
	buf[14] = GET_HIGH_BYTE(Position);        //填充目标位置的高八位
	SerialX->write(buf, 15);
}

/*
  运行动作组
  numOfAction : 动作组编号
  Times : 运行次数
*/
void xArmController::runActionGroup(uint8_t numOfAction, uint16_t Times){
	uint8_t buf[12];
  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 10;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
	buf[5] = FRAME_HEADER;                   //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 5;                              //数据长度，数据帧除帧头部分数据字节数，此命令固定为5
	buf[8] = CMD_ACTION_GROUP_RUN;           //填充运行动作组命令
	buf[9] = numOfAction;                    //填充要运行的动作组号
	buf[10] = GET_LOW_BYTE(Times);           //取得要运行次数的低八位
	buf[11] = GET_HIGH_BYTE(Times);          //取得要运行次数的高八位
	SerialX->write(buf, 12);                  //发送数据帧
  isRunning = true;
}

/*
  设置动作组运行速度
  numOfAction : 动作组编号
  Speed : 动作组运行速度,单位%
*/
void xArmController::setActionGroupSpeed(uint8_t numOfAction, uint16_t Speed){
  uint8_t buf[12];
  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 10;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
	buf[5] = FRAME_HEADER;     //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 5;                //数据长度，数据帧除帧头部分数据字节数，此命令固定为5
	buf[8] = CMD_ACTION_GROUP_SPEED; //填充设置动作组速度命令
	buf[9] = numOfAction;      //填充要设置的动作组号
	buf[10] = GET_LOW_BYTE(Speed); //获得目标速度的低八位
	buf[11] = GET_HIGH_BYTE(Speed); //获得目标熟读的高八位
	SerialX->write(buf, 12);      //发送数据帧
}

/*
  停止运行动作组
*/
void xArmController::stopActionGroup(void){
  uint8_t buf[9];
  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 7;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
	buf[5] = FRAME_HEADER;     //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 2;                //数据长度，数据帧除帧头部分数据字节数，此命令固定为2
	buf[8] = CMD_ACTION_GROUP_STOP; //填充停止运行动作组命令
	SerialX->write(buf, 9);      //发送数据帧
}

/*
  获取动作组运行状态
*/
bool xArmController::actionFinish(void){
	return isRunning;
}

/*
  固定俯仰角控制机械臂移动至对应坐标
  x : x轴坐标
  y : y轴坐标
  z : z轴坐标
  alpha : 俯仰角（-120~240）度
  time : 运行时间
*/
bool xArmController::coordinateMove(float x, float y, float z, float alpha,uint32_t time){
  uint16_t res[4];
  uint8_t buf[24];

  if(!xk.kinematic_analysis(x, y, z, alpha, res)){
    return false;
  }
  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 22;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
  buf[5] = FRAME_HEADER;     //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 17;                //数据长度，数据帧除帧头部分数据字节数
  buf[8] = CMD_SERVO_MOVE;
  buf[9] = 4;                              //要控制的舵机个数
	buf[10] = GET_LOW_BYTE(time);            //填充时间的低八位
	buf[11] = GET_HIGH_BYTE(time);           //填充时间的高八位
	buf[12] = 3;                             //3号舵机
	buf[13] = GET_LOW_BYTE(res[3]);          //填充目标位置的低八位
	buf[14] = GET_HIGH_BYTE(res[3]);         //填充目标位置的高八位
  buf[15] = 4;                             //4号舵机
	buf[16] = GET_LOW_BYTE(res[2]);          //填充目标位置的低八位
	buf[17] = GET_HIGH_BYTE(res[2]);         //填充目标位置的高八位
  buf[18] = 5;                             //5号舵机
	buf[19] = GET_LOW_BYTE(res[1]);          //填充目标位置的低八位
	buf[20] = GET_HIGH_BYTE(res[1]);         //填充目标位置的高八位
  buf[21] = 6;                             //6号舵机
	buf[22] = GET_LOW_BYTE(res[0]);          //填充目标位置的低八位
	buf[23] = GET_HIGH_BYTE(res[0]);         //填充目标位置的高八位
  SerialX->write(buf, 24);      //发送数据帧
  return true;
}

/*
  在设定的俯仰角范围内控制机械臂移动至对应坐标
  x : x轴坐标
  y : y轴坐标
  z : z轴坐标
  alpha1 : 俯仰角1（-120~240）度
  alpha2 : 俯仰角2（-120~240）度
  time : 运行时间
*/
bool xArmController::coordinateMoveInRange(float x, float y, float z, float alpha1,float alpha2,uint32_t time){
  uint16_t res[4];
  uint8_t buf[24];

  if(!xk.ki_move_adapt(x, y, z, alpha1, alpha2, res)){
    return false;
  }

  buf[0] = FRAME_HEADER;                   //填充帧头
	buf[1] = FRAME_HEADER;
	buf[2] = 22;                             //总数据长度(不含帧头)
	buf[3] = CMD;                            //功能码
	buf[4] = SUBCMD;                         //子命令
  buf[5] = FRAME_HEADER;     //填充帧头
	buf[6] = FRAME_HEADER;
	buf[7] = 17;                //数据长度，数据帧除帧头部分数据字节数
  buf[8] = CMD_SERVO_MOVE;
  buf[9] = 4;                              //要控制的舵机个数
	buf[10] = GET_LOW_BYTE(time);            //填充时间的低八位
	buf[11] = GET_HIGH_BYTE(time);           //填充时间的高八位
	buf[12] = 3;                             //3号舵机
	buf[13] = GET_LOW_BYTE(res[3]);          //填充目标位置的低八位
	buf[14] = GET_HIGH_BYTE(res[3]);         //填充目标位置的高八位
  buf[15] = 4;                             //4号舵机
	buf[16] = GET_LOW_BYTE(res[2]);          //填充目标位置的低八位
	buf[17] = GET_HIGH_BYTE(res[2]);         //填充目标位置的高八位
  buf[18] = 5;                             //5号舵机
	buf[19] = GET_LOW_BYTE(res[1]);          //填充目标位置的低八位
	buf[20] = GET_HIGH_BYTE(res[1]);         //填充目标位置的高八位
  buf[21] = 6;                             //6号舵机
	buf[22] = GET_LOW_BYTE(res[0]);          //填充目标位置的低八位
	buf[23] = GET_HIGH_BYTE(res[0]);         //填充目标位置的高八位
  SerialX->write(buf, 24);      //发送数据帧
  return true;
}

/* 接收机械臂回传数据 */
void xArmController::receiveHandle(void *p){
  xArmController *self = static_cast<xArmController*>(p);
  while(true){
    if (!self->SerialX->available()){
      String cmd = self->SerialX->readStringUntil(RESULT_END);
      if(cmd.startsWith(String((char)RESULT_HEADER)) && (cmd.length() == 3)){ //进行数据校验
        if(cmd[1] == 'F' && cmd[2] == 'R'){
          self->isRunning = false;
        }
      }
    }
    vTaskDelay(20);
  }
}