#include "esp32-hal.h"
#include "esp32-hal-adc.h"
#include "esp32-hal-gpio.h"
#include "WString.h"
#include <iterator>
#include "Hiwonder.h"
#include <Wire.h>

bool wireWriteByte(TwoWire *iic, uint8_t addr, uint8_t val){ //写字节
  iic->beginTransmission(addr);
  iic->write(val);
    if(iic->endTransmission() != 0 ) 
    {
        return false;
    }
    return true;
}

bool wireWriteDataArray(TwoWire *iic, uint8_t addr, uint8_t reg,uint8_t *val,unsigned int len){ //写多个字节
  unsigned int i;

  iic->beginTransmission(addr);
  iic->write(reg);
  for(i = 0; i < len; i++) 
  {
      iic->write(val[i]);
  }
  if( iic->endTransmission() != 0 ) 
  {
      return false;
  }
  return true;
}

int wireReadDataArray(TwoWire *iic, uint8_t addr, uint8_t reg, uint8_t *val, unsigned int len){ //读指定长度字节
  unsigned char i = 0;  
  if (!wireWriteByte(iic,addr, reg)) 
  {
      return -1;
  }
  iic->requestFrom(addr, len);
  while (iic->available()) 
  {
      if (i >= len) 
      {
          return -1;
      }
      val[i] = iic->read();
      i++;
  }
  return i;
}

void taskRun(void *p){
  CallbackFunc func = (CallbackFunc)p;
  while(1){
    func();
    vTaskDelay(100);
  }
}

void startMain(CallbackFunc ncb,uint16_t size){
  if(ncb == nullptr) return;
  xTaskCreate(             
    taskRun,          
    "userThread",       
    size,           
    (void*)ncb,           
    1,              
    NULL
  );
}


/*Buzzer*/
void Buzzer::Buzzer_init(void){  //蜂鸣器初始化
  ledcSetup(Buzzer_channel,Buzzer_freq,10);
  ledcAttachPin(Buzzer_Pin, Buzzer_channel); 
  
  xTaskCreate(             //任务初始化
    Buzzer_Task,          // 任务函数
    "Task Buzzer",       // 任务名称
    1024,           // 任务堆栈大小
    this,           // 传递给任务函数的参数
    1,              // 任务优先级
    &Buzzer_TaskHandel    // 任务句柄
  );
}

void Buzzer::Buzzer_Task(void *p){  //蜂鸣器任务
  Buzzer *self = static_cast<Buzzer*>(p);
  while(1){
    if (self->userTone) {
      ledcWrite(self->Buzzer_channel, self->duty_value);
      vTaskDelay(self->time_value);
      ledcWrite(self->Buzzer_channel, 0);
      self->userTone = false;
    }else{
      ledcWrite(self->Buzzer_channel, 0);
    }
    vTaskDelay(100);
  }
}

void Buzzer::playTone(int duty, int btime, bool state){    //设置鸣响音调
  userTone = true;
  duty_value = duty;
  time_value = btime;
  if(state) delay(btime);
}
void Buzzer::setVolume(int freq){    //设置音量[0,1000]
  Buzzer_freq = freq;
  ledcSetup(Buzzer_channel,Buzzer_freq,10);
}

/*Button*/
void Button::Button_init(uint8_t Pin){
  pinMode(Pin, INPUT_PULLUP);
  bt_key = Pin;

  xTaskCreate(             
    Button_Task,          
    "Task Button",       
    1024,           
    this,           
    1,              
    &Button_TaskHandel    
  );
}

void Button::Button_Task(void *p){
  Button *self = static_cast<Button*>(p);
  int bt_count = 0;
  int long_press = 0;
  while(1){
    if(self->bt_key == Key_A_Pin){
      if(!digitalRead(self->bt_key)){
        bt_count++;
        if(bt_count > 2) self->clicked_state = true;
        if(bt_count >= 20){
          if(long_press == 0){
            long_press = 1;
            if(self->longpressed_cb != NULL) self->longpressed_cb();
          }
        }
      }else{
        self->clicked_state = false;
        if(bt_count >= 2 && bt_count < 20){
          if(self->clicked_cb != NULL) self->clicked_cb();
        }
        long_press = 0;
        bt_count = 0;
      }
      vTaskDelay(50);
    }else if (self->bt_key == Key_B_Pin) {
      if(digitalRead(self->bt_key)){
        bt_count++;
        if(bt_count > 2) self->clicked_state = true;
        if(bt_count >= 20){
          if(long_press == 0){
            long_press = 1;
            if(self->longpressed_cb != NULL) self->longpressed_cb();
          }
        }
      }else{
        self->clicked_state = false;
        if(bt_count >= 2 && bt_count < 20){
          if(self->clicked_cb != NULL) self->clicked_cb();
        }
        long_press = 0;
        bt_count = 0;
      }
      vTaskDelay(50);
    }else{
      if(!digitalRead(self->bt_key)){
        bt_count++;
        if(bt_count > 2) self->clicked_state = true;
        if(bt_count >= 20){
          if(long_press == 0){
            long_press = 1;
            if(self->longpressed_cb != NULL) self->longpressed_cb();
          }
        }
      }else{
        self->clicked_state = false;
        if(bt_count >= 2 && bt_count < 20){
          if(self->clicked_cb != NULL) self->clicked_cb();
        }
        long_press = 0;
        bt_count = 0;
      }
      vTaskDelay(50);
    }
  }
}

int Button::GetButtonResult(void){
  return clicked_state;
}

void Button::Clicked(CallbackFunc ncb){
  if(ncb != nullptr) clicked_cb = ncb;
}

void Button::Longpressed(CallbackFunc ncb){
  if(ncb != nullptr) longpressed_cb = ncb;
}

/*RGB*/
void RGBLight::RGB_init(void){
  pixels.begin();
}

/* 点亮RGB灯
   参数1   : RGB灯的序号1~6，若为0则表示控制全部RGB灯
   参数2~4 ：红、绿、蓝三种元素的占比
*/
void RGBLight::colorFill(uint8_t num,uint8_t R,uint8_t G,uint8_t B){
  if(num == 0){
    for(int i=0; i<pixels.numPixels(); i++){
      pixels.setPixelColor(i, pixels.Color(R,G,B));
    }
    pixels.show();
  }else{
    pixels.setPixelColor(num-1, pixels.Color(R,G,B));
    pixels.show();
  }
}

void RGBLight::colorClear(void){
  pixels.clear();
  pixels.show();
}

/* SoundSensor */
void SoundSensor::begin(void){
  pinMode(Sound_Pin, INPUT_PULLUP);
}

uint8_t SoundSensor::readSound(void){
  return map(analogRead(Sound_Pin),0,4095,0,255);
}


/*LightSensor*/
void LightSensor::LightSensor_init(uint8_t port){
  LightSensorPort = port;
}

int LightSensor::read(void){
  return map(analogRead(LightSensorPort), 0, 4096, 255, 0);
}

/* UltrasoundSonar */
void UltrasoundSonar::Ultrasound_init(void){
 Wire.begin();
}

/* 
  设置灯的颜色
	参数1：0表示两边，1表示左边，2表示右边
	参数2：颜色的rgb比例值，以元组形式传入,范围0-255, 依次为r， g， b
*/
void UltrasoundSonar::setRGB(uint8_t index, uint8_t r, uint8_t g, uint8_t b){
  uint8_t RGB[3]; 
  uint8_t value = RGB_WORK_SIMPLE_MODE; //普通模式
  wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB_WORK_MODE,&value,1);
  if(index == 0){
    RGB[0] = r;RGB[1] = g;RGB[2] = b;//RGB1
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB1_R,RGB,3);
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB2_R,RGB,3); 
  }else{
    RGB[0] = r;RGB[1] = g;RGB[2] = b;//RGB1
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, (index == 1 ? RGB1_R : RGB2_R),RGB,3);
  }
}

/* 
  呼吸灯模式
  参数1：0表示两边的灯，1表示左边,2表示右边
  参数2：颜色通道， 0表示r，1表示g， 2表示b
  参数3：颜色变化周期，单位100ms，例如设置3000ms周期，该参数设置为30
*/
void UltrasoundSonar::setBreathing(uint8_t index, uint8_t rgb, uint8_t cycle){ 
  uint8_t value = RGB_WORK_BREATHING_MODE; //呼吸灯模式 
  wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB_WORK_MODE, &value, 1);
  if(index == 0){
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB1_R_BREATHING_CYCLE + rgb, &cycle,1); 
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, RGB2_R_BREATHING_CYCLE + rgb, &cycle,1); 
  }else{
    wireWriteDataArray(&Wire, ULTRASOUND_I2C_ADDR, (index == 1 ? RGB1_R_BREATHING_CYCLE : RGB2_R_BREATHING_CYCLE) + rgb, &cycle,1); 
  }
}

uint16_t UltrasoundSonar::getDistance(){ //获取超声波测得的距离，单位cm
  uint16_t distance;
  int filter_sum = 0;
  wireReadDataArray(&Wire, ULTRASOUND_I2C_ADDR, DISTANCE_ADDR,(uint8_t *)&distance,2);
  if(distance == DISTANCE_ERRO) distance = 5000;
  filter_buf[FILTER_N] = distance;     //读取超声波测值
  
  for(int i = 0; i < FILTER_N; i++) {    
    filter_buf[i] = filter_buf[i + 1];               // 所有数据左移，低位仍掉
    filter_sum += filter_buf[i];
  }
  return (uint16_t)(filter_sum / FILTER_N) / 10;
}

/* WonderEcho */
void WonderEcho::begin(void){
  send[0] = 0;
  send[1] = 0;
  Wire.begin();
}

uint8_t WonderEcho::rec_recognition(void)
{
  uint8_t result = 0;
  wireReadDataArray(&Wire,WONDERECHO_ADDR,ECHO_RESULT_ADDR,&result,1);
  return result;
}

void WonderEcho::speak(uint8_t cmd , uint8_t id)
{
  if(cmd == 0xFF || cmd == 0x00)
  {
    send[0] = cmd;
    send[1] = id;
    wireWriteDataArray(&Wire,WONDERECHO_ADDR,ECHO_SPEAK_ADDR,send,2);
  }
}

/* InfraredSensor */
void InfraredSensor::InfraredSensor_init(uint8_t port){
  InfraredSensorPort = port;
  pinMode(InfraredSensorPort, INPUT_PULLUP);
}

uint8_t InfraredSensor::getIRValue(void){
  return !digitalRead(InfraredSensorPort);
}

/* AccelerationSensor */
void AccelerationSensor::begin(){
  Wire.begin();
  accelgyro.initialize();
  accelgyro.setFullScaleGyroRange(3); //设定角速度量程
  accelgyro.setFullScaleAccelRange(1); //设定加速度量程
  delay(200);
  accelgyro.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);  //获取当前各轴数据以校准
  ax_offset = ax;  //X轴加速度校准数据
  ay_offset = ay;  //Y轴加速度校准数据
  az_offset = az - 8192;  //Z轴加速度校准数据
  gx_offset = gx; //X轴角速度校准数据
  gy_offset = gy; //Y轴角速度校准数据
  gz_offset = gz; //Z轴教书的校准数据
}

void AccelerationSensor::updateData(){
    accelgyro.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    ax0 = ((float)(ax)) * 0.3 + ax0 * 0.7;  //对读取到的值进行滤波
    ay0 = ((float)(ay)) * 0.3 + ay0 * 0.7;
    az0 = ((float)(az)) * 0.3 + az0 * 0.7;
    ax1 = (ax0 - ax_offset) /  8192.0;  // 校正，并转为重力加速度的倍数
    ay1 = (ay0 - ay_offset) /  8192.0;
    az1 = (az0 - az_offset) /  8192.0;

    gx0 = ((float)(gx)) * 0.3 + gx0 * 0.7;  //对读取到的角速度的值进行滤波
    gy0 = ((float)(gy)) * 0.3 + gy0 * 0.7;
    gz0 = ((float)(gz)) * 0.3 + gz0 * 0.7;
    gx1 = (gx0 - gx_offset);  //校正角速度
    gy1 = (gy0 - gy_offset);
    gz1 = (gz0 - gz_offset);

    //互补计算x轴倾角
    radianX = atan2(ay1, az1);
    AngleX = radianX * 180.0 / 3.1415926;
    radian_temp = (float)(gx1) / 16.4 * 0.02;
    radianX_last = 0.8 * (radianX_last + radian_temp) + (-AngleX) * 0.2;

    //互补计算y轴倾角
    radianY = atan2(ax1, az1);
    AngleY = radianY * 180.0 / 3.1415926;
    radian_temp = (float)(gy1) / 16.4 * 0.01;
    radianY_last = 0.8 * (radianY_last + radian_temp) + (-AngleY) * 0.2;

    //互补计算z轴倾角
    radianZ = atan2(sqrt(ax1 * ax1 + ay1 * ay1), az1);
    AngleZ = radianZ * 180.0 / 3.1415926;
    radian_temp = (float)(gz1) / 16.4 * 0.02;
    radianZ_last = 0.8 * (radianZ_last + radian_temp) + (-AngleZ) * 0.2;
}

int16_t AccelerationSensor::getRadian(uint8_t xyz){
  switch (xyz) {
    case X:
      return radianX;
    case Y:
      return radianY;
    case Z:
      return radianZ;
    default:
      return 0;
  }
}

int16_t AccelerationSensor::getAngle(uint8_t xyz){
  switch (xyz) {
    case X:
      return radianX_last;
    case Y:
      return radianY_last;
    case Z:
      return radianZ_last;
    default:
      return 0;
  }
}

float AccelerationSensor::getTemperature(void){
  temperature = accelgyro.getTemperature() / 340.0 + 36.53;
  return temperature;
}

/* FanSensor */
void FanSensor::FanModule_init(uint8_t port){
  switch(port){
    case Port_6_Pin:
      pin1 = 25;
      pin2 = 33;
      break;
    case Port_8_Pin:
      pin1 = 27;
      pin2 = 26;
      break;
  }
}

void FanSensor::setSpeed(int16_t speed){
  if(speed > 255 || speed < -255){
    fan_speed = 255;
  }else{
    fan_speed = abs(speed);
  }

  if(speed > 0){
    analogWrite(pin1, fan_speed);
    analogWrite(pin2, 0);
  }else if(speed < 0){
    analogWrite(pin1, 0);
    analogWrite(pin2, fan_speed);
  }else{
    analogWrite(pin1, 0);
    analogWrite(pin2, 0);
  }
}

/* AHTSensor */
void AHTSensor::begin(){
  aht10.begin();
}

float AHTSensor::getTemperature(void){
  return aht10.readTemperature();
}

float AHTSensor::getHumidity(void){
  return aht10.readHumidity();
}


/* ColorSensor */
void ColorSensor::begin(){
  uint8_t en = 0x03;
  uint8_t at = 252;
  Wire.begin();
  wireWriteDataArray(&Wire,APDS9960_ADDRESS,APDS9960_ENABLE,&en,1);
  wireWriteDataArray(&Wire,APDS9960_ADDRESS,APDS9960_ATIME,&at,1);

}

/* 获取传感器颜色 */
uint8_t ColorSensor::readColor(void){
  uint8_t r_data,g_data,b_data;
  uint8_t r_result[2];
  uint8_t g_result[2];
  uint8_t b_result[2];
  uint8_t c_result[2];
  
  wireReadDataArray(&Wire,APDS9960_ADDRESS,APDS9960_RDATAL,r_result,2);
  wireReadDataArray(&Wire,APDS9960_ADDRESS,APDS9960_GDATAL,g_result,2);
  wireReadDataArray(&Wire,APDS9960_ADDRESS,APDS9960_BDATAL,b_result,2);

  r_data = map((r_result[0]<<8) | r_result[1], 0, 65535, 0, 255);  //取值范围缩放
  g_data = map((g_result[0]<<8) | g_result[1], 0, 65535, 0, 255);
  b_data = map((b_result[0]<<8) | b_result[1], 0, 65535, 0, 255);
  
  if (r_data > g_data + 20 && r_data > b_data + 20) {
        return RED;
    } else if (g_data > r_data + 40 && g_data > b_data) {
        return GREEN;
    } else if (b_data > r_data + 20 && b_data > g_data + 20) {
        return BLUE;
    } else if (r_data > b_data + 20 && g_data > b_data + 20 && abs(r_data - g_data) < 40) {
        return YELLOW;
    } else {
        return 0;
    }
}

