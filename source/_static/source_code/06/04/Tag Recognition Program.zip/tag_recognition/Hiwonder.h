#include "Wire.h"
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <MPU6050.h>
#include "AHTxx.h"
#include "WMMatrixLed.h"

#ifndef HIWONDER_H
#define HIWONDER_H

#define Freq_default 1000
#define Channel_default 11
#define Pin_default 15

#define Key_A_Pin 0  //按键A
#define Key_B_Pin 2  //按键B
#define Port_1_Pin 36  //接口1
#define Port_2_Pin 32  //接口2
#define Port_6_Pin 33  //接口6
#define Port_8_Pin 26  //接口8

#define RGB_Pin 23  //RGB灯

#define Sound_Pin 34

/* Ultrasound */
#define ULTRASOUND_I2C_ADDR 0x77  //发光超声波模块IIC地址
#define DISTANCE_ADDR 0
#define DISTANCE_L    0
#define DISTANCE_H    1
#define RGB_WORK_MODE 2//RGB灯模式，0：用户自定义模式   1：呼吸灯模式  默认0
#define RGB1_R      3//1号探头的R值，0~255，默认0
#define RGB1_G      4//默认0
#define RGB1_B      5//默认255
#define RGB2_R      6//2号探头的R值，0~255，默认0
#define RGB2_G      7//默认0
#define RGB2_B      8//默认255
#define RGB1_R_BREATHING_CYCLE      9 //呼吸灯模式时，1号探头的R的呼吸周期，单位100ms 默认0，
#define RGB1_G_BREATHING_CYCLE      10
#define RGB1_B_BREATHING_CYCLE      11
#define RGB2_R_BREATHING_CYCLE      12//2号探头
#define RGB2_G_BREATHING_CYCLE      13
#define RGB2_B_BREATHING_CYCLE      14
#define RGB_WORK_SIMPLE_MODE    0 //灯光设置模式
#define RGB_WORK_BREATHING_MODE   1 //呼吸灯模式
#define FILTER_N 3
#define DISTANCE_ERRO 65535

/* WonderEcho */
#define WONDERECHO_ADDR 0x34
#define ECHO_RESULT_ADDR   100
#define ECHO_SPEAK_ADDR    110

#define ECHO_CMDMAND    0x00
#define ECHO_ANNOUNCER  0xFF

/* AccelerationSensor */
#define X 0
#define Y 1
#define Z 2

/* ColorSensor */
#define APDS9960_ADDRESS 0x39
#define APDS9960_CDATAL 0x94
#define APDS9960_RDATAL 0x96
#define APDS9960_RDATAH 0x97
#define APDS9960_GDATAL 0x98
#define APDS9960_GDATAH 0x99
#define APDS9960_BDATAL 0x9A
#define APDS9960_BDATAH 0x9B
#define APDS9960_ENABLE 0x80
#define APDS9960_ATIME 0x81

#define RED 1
#define GREEN 2
#define BLUE 3
#define YELLOW 4

static int filter_buf[FILTER_N + 1];
typedef void (*CallbackFunc)();

bool wireWriteByte(TwoWire *iic, uint8_t addr, uint8_t val);
bool wireWriteDataArray(TwoWire *iic, uint8_t addr, uint8_t reg,uint8_t *val,unsigned int len);
int wireReadDataArray(TwoWire *iic, uint8_t addr, uint8_t reg, uint8_t *val, unsigned int len);

void taskRun(void *p);
void startMain(CallbackFunc ncb,uint16_t size);

class Buzzer{
  private:
    int Buzzer_freq;
    int Buzzer_channel;
    int Buzzer_Pin;
    int duty_value;
    int time_value;
    bool bt_open;
    bool bt_state;
    bool userTone;
    TaskHandle_t Buzzer_TaskHandel;
    static void Buzzer_Task(void *p);

  public:
    Buzzer(void){
      Buzzer_freq = Freq_default; 
      Buzzer_channel = Channel_default; 
      Buzzer_Pin = Pin_default;
      bt_open = true;
      bt_state = false;
      userTone = false;
      Buzzer_TaskHandel = NULL;
    };

    void Buzzer_init(void);
    void playTone(int duty, int btime, bool bg_State);
    void setVolume(int freq);
};

class Button{
  private:
    int bt_key;
    bool clicked_state;
    CallbackFunc clicked_cb;
    CallbackFunc longpressed_cb;
    TaskHandle_t Button_TaskHandel;
    static void Button_Task(void *p);
  public:
    Button(void){
      bt_key = 0;
      clicked_state = false;
      clicked_cb = nullptr;
      longpressed_cb = nullptr;
      Button_TaskHandel = NULL;
    };
    int GetButtonResult(void);
    void Button_init(uint8_t num);
    void Clicked(CallbackFunc ncb);
    void Longpressed(CallbackFunc ncb);
};

class RGBLight{
  private:
    Adafruit_NeoPixel pixels;
  public:
    RGBLight(void):pixels(6, RGB_Pin, NEO_GRB + NEO_KHZ800){};
    void RGB_init(void);
    void colorFill(uint8_t num,uint8_t R,uint8_t G,uint8_t B); //点亮RGB灯
    void colorClear(void); //关闭所有RGB灯
};

class SoundSensor{
  public:
    void begin(void);
    uint8_t readSound(void);
};

class LightSensor{
  private:
    uint8_t LightSensorPort;
  public:
    void LightSensor_init(uint8_t port); //初始化接口号1/2/6
    int read(void);
};

class UltrasoundSonar{
  public:
    void Ultrasound_init(void);
    void setRGB(uint8_t index, uint8_t r, uint8_t g, uint8_t b);
    void setBreathing(uint8_t index, uint8_t rgb, uint8_t cycle);
    uint16_t getDistance(void);
};

class WonderEcho{
  private:
    uint8_t send[2];
  public:
    void begin(void);
    uint8_t rec_recognition(void);
    void speak(uint8_t cmd , uint8_t id);
};

class InfraredSensor{
  private:
    uint8_t InfraredSensorPort;
  public:
    void InfraredSensor_init(uint8_t port); //初始化接口号1/2/6/8
    uint8_t getIRValue(void);
};

class AccelerationSensor{
  private:
    MPU6050 accelgyro;
    int16_t ax, ay, az;
    int16_t gx, gy, gz;
    float ax0, ay0, az0;
    float gx0, gy0, gz0;
    float ax1, ay1, az1;
    float gx1, gy1, gz1;
    float dx;
    float dz;
    int ax_offset, ay_offset, az_offset, gx_offset, gy_offset, gz_offset;
    float radian_temp;
    float radianX; //X轴弧度
    float radianY; //Y轴弧度
    float radianZ; //Z轴弧度
    float AngleX; //X轴角度
    float AngleY; //Y轴角度
    float AngleZ; //Z轴角度
    float radianX_last; //最终获得的X轴倾角
    float radianY_last; //最终获得的Y轴倾角
    float radianZ_last; //最终获得的Y轴倾角
    float temperature;
    
  public:
    void begin(void);
    void updateData(void);
    int16_t getRadian(uint8_t xyz);
    int16_t getAngle(uint8_t xyz);
    float getTemperature(void);
};

class FanSensor{
  private:
    uint8_t pin1;
    uint8_t pin2;
    int8_t fan_speed;
  public:
    void FanModule_init(uint8_t port);
    void setSpeed(int16_t speed);
};

class AHTSensor{
  private:
    AHTxx aht10;
  public:
    AHTSensor():aht10(AHTXX_ADDRESS_X38, AHT1x_SENSOR){};
    void begin(void);
    float getTemperature(void);
    float getHumidity(void);
};

class ColorSensor{
  public:
    void begin(void);
    uint8_t readColor(void);
};

#endif  //HIWONDER_H
