#include <sys/types.h>
#include <Arduino.h>
#include "HardwareSerial.h"
#include "xArm.h"

#define FRAME_HEADER            0x55   //帧头
#define CMD                     0x3F   //功能码
#define SUBCMD                  0x09   //子命令
#define CMD_SERVO_MOVE          0X03   //舵机转动指令
#define CMD_ACTION_GROUP_RUN    0x06   //运行动作组指令
#define CMD_ACTION_GROUP_STOP   0x07   //停止动作组指令
#define CMD_ACTION_GROUP_SPEED  0x0B   //设置动作组运行速度指令
#define CMD_GET_BATTERY_VOLTAGE 0x0F   //获得电池电压指令

#define RESULT_HEADER           0x41   //返回帧头
#define RESULT_END              0x24   //返回帧尾

#define rxPin 16
#define txPin 17

class xArmController{
  private:
    HardwareSerial *SerialX;
    bool isRunning; //动作组运行标志位
    xArmKinematic xk;
    static void receiveHandle(void *p); /* 接收数据 */

  public:
    xArmController(void);
    xArmController(HardwareSerial &S);
    void begin(); /* 初始化 */
    
    void moveServo(uint8_t servoID, uint16_t Position, uint16_t Time); /* 控制舵机转动 */
    void runActionGroup(uint8_t numOfAction, uint16_t Times); /* 运行动作组 */
    void setActionGroupSpeed(uint8_t numOfAction, uint16_t Speed); /* 设置动作组运行速度 */
    void stopActionGroup(); /* 停止动作组运行 */
    bool actionFinish(); /* 获取动作组运行状态 */
    bool coordinateMove(float x, float y, float z, float alpha,uint32_t time); /* 固定俯仰角控制机械臂移动至对应坐标 */
    bool coordinateMoveInRange(float x, float y, float z, float alpha1,float alpha2,uint32_t time); /* 在设定的俯仰角范围内控制机械臂移动至对应坐标 */

};