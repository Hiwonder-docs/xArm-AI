#include <math.h>
#define PI 3.1415926f 

class xArmKinematic{
  private:
    float L1;  //底盘到第2个舵机中心轴的距离 (由下至上)
    float L2;  //第2个舵机到第3个舵机的距离
    float L3;  //第3个舵机到第4个舵机的距离
    float L4;  //第4个舵机到最高点的距离
    
  public:
    xArmKinematic(){
      L1 = 6.9;
      L2 = 9.5;
      L3 = 9.5;
      L4 = 16.9;
    };
    bool kinematic_analysis(float x, float y, float z, float Alpha ,uint16_t *result);
    bool ki_move_adapt(float x, float y, float z, float Alpha1, float Alpha2,uint16_t *result);
    void set_link_length(float L1, float L2, float L3, float L4);
};