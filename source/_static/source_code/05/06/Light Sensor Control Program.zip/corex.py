import Hiwonder
import time
from Hiwonder import LSC
import Hiwonder_ADC

# initialize variables
light_intensity_now = 0
light_intensity_max = 0
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
light_1 = Hiwonder_ADC.LightSensor(Hiwonder.Port(1))
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))


def start_main():
  global light_intensity_now
  global light_intensity_max
  global digitalTube_6
  global light_1
  global i2csonar_3

  LSC.runActionGroup(0,1)
  light_intensity_now = 0
  light_intensity_max = 255
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  while True:
    light_intensity_now = light_1.read()
    digitalTube_6.showNum((light_intensity_now,1))
    Hiwonder.Neopixel_onboard.fill(light_intensity_now,0,(light_intensity_max-light_intensity_now))
    i2csonar_3.setRGB(0,light_intensity_now,0,(light_intensity_max-light_intensity_now))
    time.sleep(1)

Hiwonder.startMain(start_main)
