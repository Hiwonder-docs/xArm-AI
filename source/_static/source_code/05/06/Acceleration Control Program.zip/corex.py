import Hiwonder
import time
from Hiwonder import LSC
import Hiwonder_MPU
import kinematics

# initialize variables
mpu_4 = Hiwonder_MPU.MPU(Hiwonder.Port(4))
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
euler_angle_X = 0
euler_angle_Y = 0
num = 0
ForwardClamp_angle_x_Threshold = 0
LayRight_angle_y_Threshold = 0
LayLeft_angle_y_Threshold = 0
PickUp_state = 0
angle_y_last = 0


def start_main():
  global mpu_4
  global digitalTube_6
  global euler_angle_X
  global euler_angle_Y
  global num
  global ForwardClamp_angle_x_Threshold
  global LayRight_angle_y_Threshold
  global LayLeft_angle_y_Threshold
  global PickUp_state
  global angle_y_last

  LSC.runActionGroup(0,1)
  mpu_4.set_bias()
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  euler_angle_X = 0
  euler_angle_Y = 0
  num = 0
  ForwardClamp_angle_x_Threshold = 30
  LayRight_angle_y_Threshold = -30
  LayLeft_angle_y_Threshold = 30
  PickUp_state = 0
  angle_y_last = 0
  while True:
    if LSC.actionFinish():
      digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
      euler_angle_X = mpu_4.get_euler_angles_degree()[0]
      euler_angle_Y = mpu_4.get_euler_angles_degree()[1]
      if (PickUp_state==0):
        if (euler_angle_X>ForwardClamp_angle_x_Threshold):
          num+=1
          if (num>3):
            num = 0
            PickUp_state = 1
            digitalTube_6.drawStr((0,0,'GO'))
            kinematics.ki_move(0,17,1.2,-71,500)
            time.sleep(0.8)
            LSC.moveServo(1,500,400)
            time.sleep(0.8)
            kinematics.ki_move(0,17,20.5,0,500)
            time.sleep(0.8)
        else:
          num = 0
      else:
        if (euler_angle_Y>LayLeft_angle_y_Threshold):
          if (angle_y_last<=LayLeft_angle_y_Threshold):
            num = 0
          num+=1
          if (num>3):
            num = 0
            PickUp_state = 0
            digitalTube_6.drawStr((5,0,'L'))
            LSC.runActionGroup(6,1)
        else:
          if (euler_angle_Y<LayRight_angle_y_Threshold):
            if (angle_y_last>=LayRight_angle_y_Threshold):
              num = 0
            num+=1
            if (num>3):
              num = 0
              PickUp_state = 0
              digitalTube_6.drawStr((5,0,'R'))
              LSC.runActionGroup(9,1)
        angle_y_last = euler_angle_Y
      time.sleep(0.05)

Hiwonder.startMain(start_main)
