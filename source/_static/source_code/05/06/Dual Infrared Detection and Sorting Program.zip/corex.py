import Hiwonder
import time
import kinematics
from Hiwonder import LSC
import Hiwonder_SimpleIO
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))
target_area = 0
avoid_8 = Hiwonder_SimpleIO.AvoidObstacles(Hiwonder.Port(8))
avoid_2 = Hiwonder_SimpleIO.AvoidObstacles(Hiwonder.Port(2))


def start_main():
  global cam
  global i2csonar_3
  global target_area
  global avoid_8
  global avoid_2

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  LSC.moveServo(1,100,500)
  kinematics.ki_move(0,17,20.5,0,1000)
  cam.setLed(cam.LED_ON)
  cam.switchFunc(cam.ColorDetect)
  i2csonar_3.setRGB(0,0x00,0x00,0x00)
  target_area = 0
  time.sleep(2)
  while True:
    if (i2csonar_3.getDistance()<=6):
      i2csonar_3.setRGB(0,255,255,255)
      Straight_ahead_detect()
      i2csonar_3.setRGB(0,0x00,0x00,0x00)
    else:
      if avoid_8.read()==0:
        Left_detect()
      else:
        if avoid_2.read()==0:
          Right_detect()
    time.sleep(0.1)
    Hiwonder.Neopixel_onboard.clear()
    time.sleep(0.01)

def Straight_ahead_detect():
  global cam
  global i2csonar_3
  global target_area
  global avoid_8
  global avoid_2

  kinematics.ki_move(0,11,3.7,-68,500)
  time.sleep(2.5)
  cam.updateResult()
  if cam.isColorOfIdDetected(1):
    time.sleep(0.2)
    cam.updateResult()
    if cam.isColorOfIdDetected(1):
      target_area = (cam.getColorOfId(1)[2]*cam.getColorOfId(1)[3])
      if (target_area>1000):
        Hiwonder.Neopixel_onboard.fill(255,0,0)
        Buzzer.playTone(1976,500,True)
        time.sleep(1.5)
        kinematics.ki_move(0,17,1.2,-71,800)
        time.sleep(0.8)
        LSC.moveServo(1,500,400)
        time.sleep(0.8)
        kinematics.ki_move(0,17,20.5,0,800)
        time.sleep(0.8)
        LSC.runActionGroup(6,1)
        time.sleep(4.8)
      else:
        Hiwonder.Neopixel_onboard.clear()
        time.sleep(0.01)
  else:
    if cam.isColorOfIdDetected(2):
      time.sleep(0.2)
      cam.updateResult()
      if cam.isColorOfIdDetected(2):
        target_area = (cam.getColorOfId(2)[2]*cam.getColorOfId(2)[3])
        if (target_area>1000):
          Hiwonder.Neopixel_onboard.fill(0,255,0)
          Buzzer.playTone(1976,500,True)
          time.sleep(1.5)
          kinematics.ki_move(0,17,1.2,-71,800)
          time.sleep(0.8)
          LSC.moveServo(1,500,400)
          time.sleep(0.8)
          kinematics.ki_move(0,17,20.5,0,800)
          time.sleep(0.8)
          LSC.runActionGroup(7,1)
          time.sleep(4.8)
        else:
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
    else:
      if cam.isColorOfIdDetected(3):
        time.sleep(0.2)
        cam.updateResult()
        if cam.isColorOfIdDetected(3):
          target_area = (cam.getColorOfId(3)[2]*cam.getColorOfId(3)[3])
          if (target_area>1000):
            Hiwonder.Neopixel_onboard.fill(0,0,255)
            Buzzer.playTone(1976,500,True)
            time.sleep(1.5)
            kinematics.ki_move(0,17,1.2,-71,800)
            time.sleep(0.8)
            LSC.moveServo(1,500,400)
            time.sleep(0.8)
            kinematics.ki_move(0,17,20.5,0,800)
            time.sleep(0.8)
            LSC.runActionGroup(8,1)
            time.sleep(4.8)
          else:
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)
      else:
        if cam.isColorOfIdDetected(4):
          time.sleep(0.2)
          cam.updateResult()
          if cam.isColorOfIdDetected(4):
            target_area = (cam.getColorOfId(4)[2]*cam.getColorOfId(4)[3])
            if (target_area>1000):
              Hiwonder.Neopixel_onboard.fill(255,255,0)
              Buzzer.playTone(1976,500,True)
              time.sleep(1.5)
              kinematics.ki_move(0,17,1.2,-71,800)
              time.sleep(0.8)
              LSC.moveServo(1,500,400)
              time.sleep(0.8)
              kinematics.ki_move(0,17,20.5,0,800)
              time.sleep(0.8)
              LSC.runActionGroup(9,1)
              time.sleep(4.8)
            else:
              Hiwonder.Neopixel_onboard.clear()
              time.sleep(0.01)
        else:
          kinematics.ki_move(0,17,20.5,0,500)
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
          time.sleep(1)

def Left_detect():
  global cam
  global i2csonar_3
  global target_area
  global avoid_8
  global avoid_2

  kinematics.ki_move(-8,0,3.7,-62,500)
  time.sleep(2.5)
  cam.updateResult()
  if cam.isColorOfIdDetected(1):
    time.sleep(0.2)
    cam.updateResult()
    if cam.isColorOfIdDetected(1):
      target_area = (cam.getColorOfId(1)[2]*cam.getColorOfId(1)[3])
      if (target_area>1000):
        Hiwonder.Neopixel_onboard.fill(255,0,0)
        Buzzer.playTone(1976,500,True)
        time.sleep(1.5)
        kinematics.ki_move(-11,0,0.5,-73,800)
        time.sleep(0.8)
        LSC.moveServo(1,500,400)
        time.sleep(0.8)
        kinematics.ki_move(-17,0,20.5,0,800)
        time.sleep(0.8)
        LSC.runActionGroup(6,1)
        time.sleep(4.8)
      else:
        Hiwonder.Neopixel_onboard.clear()
        time.sleep(0.01)
  else:
    if cam.isColorOfIdDetected(2):
      time.sleep(0.2)
      cam.updateResult()
      if cam.isColorOfIdDetected(2):
        target_area = (cam.getColorOfId(2)[2]*cam.getColorOfId(2)[3])
        if (target_area>1000):
          Hiwonder.Neopixel_onboard.fill(0,255,0)
          Buzzer.playTone(1976,500,True)
          time.sleep(1.5)
          kinematics.ki_move(-11,0,0.5,-73,800)
          time.sleep(0.8)
          LSC.moveServo(1,500,400)
          time.sleep(0.8)
          kinematics.ki_move(-17,0,20.5,0,800)
          time.sleep(0.8)
          LSC.runActionGroup(7,1)
          time.sleep(4.8)
        else:
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
    else:
      if cam.isColorOfIdDetected(3):
        time.sleep(0.2)
        cam.updateResult()
        if cam.isColorOfIdDetected(3):
          target_area = (cam.getColorOfId(3)[2]*cam.getColorOfId(3)[3])
          if (target_area>1000):
            Hiwonder.Neopixel_onboard.fill(0,0,255)
            Buzzer.playTone(1976,500,True)
            time.sleep(1.5)
            kinematics.ki_move(-11,0,0.5,-73,800)
            time.sleep(0.8)
            LSC.moveServo(1,500,400)
            time.sleep(0.8)
            kinematics.ki_move(-17,0,20.5,0,800)
            time.sleep(0.8)
            LSC.runActionGroup(8,1)
            time.sleep(4.8)
          else:
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)
      else:
        if cam.isColorOfIdDetected(4):
          time.sleep(0.2)
          cam.updateResult()
          if cam.isColorOfIdDetected(4):
            target_area = (cam.getColorOfId(4)[2]*cam.getColorOfId(4)[3])
            if (target_area>1000):
              Hiwonder.Neopixel_onboard.fill(255,255,0)
              Buzzer.playTone(1976,500,True)
              time.sleep(1.5)
              kinematics.ki_move(-11,0,0.5,-73,800)
              time.sleep(0.8)
              LSC.moveServo(1,500,400)
              time.sleep(0.8)
              kinematics.ki_move(-17,0,20.5,0,800)
              time.sleep(0.8)
              LSC.runActionGroup(9,1)
              time.sleep(4.8)
            else:
              Hiwonder.Neopixel_onboard.clear()
              time.sleep(0.01)
        else:
          kinematics.ki_move(0,17,20.5,0,500)
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
          time.sleep(1)

def Right_detect():
  global cam
  global i2csonar_3
  global target_area
  global avoid_8
  global avoid_2

  kinematics.ki_move(8,0,3.7,-62,500)
  time.sleep(2.5)
  cam.updateResult()
  if cam.isColorOfIdDetected(1):
    time.sleep(0.2)
    cam.updateResult()
    if cam.isColorOfIdDetected(1):
      target_area = (cam.getColorOfId(1)[2]*cam.getColorOfId(1)[3])
      if (target_area>1000):
        Hiwonder.Neopixel_onboard.fill(255,0,0)
        Buzzer.playTone(1976,500,True)
        time.sleep(1.5)
        kinematics.ki_move(11,0,0.5,-73,800)
        time.sleep(0.8)
        LSC.moveServo(1,500,400)
        time.sleep(0.8)
        kinematics.ki_move(17,0,20.5,0,800)
        time.sleep(0.8)
        LSC.runActionGroup(6,1)
        time.sleep(4.8)
      else:
        Hiwonder.Neopixel_onboard.clear()
        time.sleep(0.01)
  else:
    if cam.isColorOfIdDetected(2):
      time.sleep(0.2)
      cam.updateResult()
      if cam.isColorOfIdDetected(2):
        target_area = (cam.getColorOfId(2)[2]*cam.getColorOfId(2)[3])
        if (target_area>1000):
          Hiwonder.Neopixel_onboard.fill(0,255,0)
          Buzzer.playTone(1976,500,True)
          time.sleep(1.5)
          kinematics.ki_move(11,0,0.5,-73,800)
          time.sleep(0.8)
          LSC.moveServo(1,500,400)
          time.sleep(0.8)
          kinematics.ki_move(17,0,20.5,0,800)
          time.sleep(0.8)
          LSC.runActionGroup(7,1)
          time.sleep(4.8)
        else:
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
    else:
      if cam.isColorOfIdDetected(3):
        time.sleep(0.2)
        cam.updateResult()
        if cam.isColorOfIdDetected(3):
          target_area = (cam.getColorOfId(3)[2]*cam.getColorOfId(3)[3])
          if (target_area>1000):
            Hiwonder.Neopixel_onboard.fill(0,0,255)
            Buzzer.playTone(1976,500,True)
            time.sleep(1.5)
            kinematics.ki_move(11,0,0.5,-73,800)
            time.sleep(0.8)
            LSC.moveServo(1,500,400)
            time.sleep(0.8)
            kinematics.ki_move(17,0,20.5,0,800)
            time.sleep(0.8)
            LSC.runActionGroup(8,1)
            time.sleep(4.8)
          else:
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)
      else:
        if cam.isColorOfIdDetected(4):
          time.sleep(0.2)
          cam.updateResult()
          if cam.isColorOfIdDetected(4):
            target_area = (cam.getColorOfId(4)[2]*cam.getColorOfId(4)[3])
            if (target_area>1000):
              Hiwonder.Neopixel_onboard.fill(255,255,0)
              Buzzer.playTone(1976,500,True)
              time.sleep(1.5)
              kinematics.ki_move(11,0,0.5,-73,800)
              time.sleep(0.8)
              LSC.moveServo(1,500,400)
              time.sleep(0.8)
              kinematics.ki_move(17,0,20.5,0,800)
              time.sleep(0.8)
              LSC.runActionGroup(9,1)
              time.sleep(4.8)
            else:
              Hiwonder.Neopixel_onboard.clear()
              time.sleep(0.01)
        else:
          kinematics.ki_move(0,17,20.5,0,500)
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
          time.sleep(1)

Hiwonder.startMain(start_main)

