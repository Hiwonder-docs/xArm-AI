import Hiwonder
import time
from Hiwonder import LSC

# initialize variables
trigger_times_this_round = 0
trigger_times_last_round = 0
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
state_waitting_handle = 0
extbutton_8= Hiwonder.Button(Hiwonder.Port(8))


def start_main():
  global trigger_times_this_round
  global trigger_times_last_round
  global digitalTube_6
  global state_waitting_handle
  global extbutton_8

  LSC.runActionGroup(0,1)
  trigger_times_this_round = 0
  trigger_times_last_round = 0
  while True:
    if LSC.actionFinish():
      Hiwonder.Neopixel_onboard.fill(0,0,0)
      while not (trigger_times_last_round==trigger_times_this_round):
        trigger_times_last_round = trigger_times_this_round
        time.sleep(1.5)
      digitalTube_6.showNum((trigger_times_this_round,1))
      if ((state_waitting_handle==1) and (trigger_times_last_round==trigger_times_this_round)):
        trigger_times_last_round = 0
        if (trigger_times_this_round==1):
          Hiwonder.Neopixel_onboard.fill(255,0,0)
          LSC.runActionGroup(2,1)
        else:
          if (trigger_times_this_round==2):
            Hiwonder.Neopixel_onboard.fill(0,255,0)
            LSC.runActionGroup(3,1)
          else:
            if (trigger_times_this_round==3):
              Hiwonder.Neopixel_onboard.fill(0,0,255)
              LSC.runActionGroup(4,1)
            else:
              if (trigger_times_this_round==4):
                Hiwonder.Neopixel_onboard.fill(0xfd,0xd0,0x00)
                LSC.runActionGroup(5,1)
        state_waitting_handle = 0
        trigger_times_this_round = 0
      time.sleep(0.5)


def on_extbutton_8_clicked():
  global trigger_times_this_round
  global trigger_times_last_round
  global digitalTube_6
  global state_waitting_handle
  global extbutton_8

  if (state_waitting_handle==0):
    state_waitting_handle = 1
  if (state_waitting_handle==1):
    if (trigger_times_this_round<4):
      trigger_times_this_round+=1

Hiwonder.startMain(start_main)
extbutton_8.Clicked(on_extbutton_8_clicked)

