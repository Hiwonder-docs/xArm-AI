import Hiwonder
import time
from Hiwonder import LSC
import Hiwonder_Fan

# initialize variables
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
temprature = 0
temphumiSensor_5 = Hiwonder.TempSensor(Hiwonder.Port(4))
fan_8 = Hiwonder_Fan.Fan(Hiwonder.Port(8))


def start_main():
  global digitalTube_6
  global temprature
  global temphumiSensor_5
  global fan_8

  LSC.runActionGroup(0,1)
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  while True:
    temprature = temphumiSensor_5.readTemp()
    digitalTube_6.showNum((temprature,1))
    if (temprature>31):
      fan_8.set_speed(80)
    else:
      fan_8.set_speed(0)
    time.sleep(2)

Hiwonder.startMain(start_main)
