import Hiwonder
import time
from Hiwonder import LSC
import math
import Hiwonder_Fan

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
X = 0
Z = 0
X_delta = 0
face_index = 0
id = 0
dx = 0
dz = 0
fan_8 = Hiwonder_Fan.Fan(Hiwonder.Port(8))


def start_main():
  global cam
  global X
  global Z
  global X_delta
  global face_index
  global id
  global dx
  global dz
  global fan_8

  cam.setLed(cam.LED_OFF)
  cam.switchFunc(cam.FaceDetect)
  LSC.runActionGroup(0,1)
  X = 500
  Z = 310
  X_delta = 20
  face_index = 1
  time.sleep(1)
  while True:
    cam.updateResult()
    if cam.isAnyFaceDetected():
      if cam.isAnyLearnedFaceRec():
        while not (face_index>5):
          if cam.isFaceOfIdRec(face_index):
            id = face_index
            break
          face_index+=1
        dx = (cam.getFaceOfId(face_index)[0]-160)
        dz = (cam.getFaceOfId(face_index)[1]-120)
      if cam.isAnyUnlearnedFaceDetected():
        dx = (cam.getUnlearnedFaceOfIndex(1)[0]-160)
        dz = (cam.getUnlearnedFaceOfIndex(1)[1]-120)
        
      fan_8.set_speed(80)
      
      if (math.fabs(dx)>10):
        X+=round((dx/-8))
        if (X>1000):
          X = 1000
        if (X<0):
          X = 0
        LSC.moveServo(6,X,200)
      if (math.fabs(dz)>5):
        Z+=round((dz/-10))
        if (Z>1000):
          Z = 1000
        if (Z<0):
          Z = 0
        LSC.moveServo(3,Z,200)
      time.sleep(0.1)
    else:
      face_index = 1
      LSC.moveServo(3,310,1000)
      X+=X_delta
      if (X>800):
        X = 800
        X_delta = (0-X_delta)
      if (X<200):
        X = 200
        X_delta = 20
        
      fan_8.set_speed(0)
      
      LSC.moveServo(6,X,200)
      time.sleep(0.12)

Hiwonder.startMain(start_main)

