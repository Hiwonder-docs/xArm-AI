import Hiwonder
import time
from Hiwonder import LSC

# initialize variables
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))


def start_main():
  global digitalTube_6

  LSC.runActionGroup(0,1)
  while True:
    digitalTube_6.drawStr((3,0,'Hi'))
    time.sleep(1)
    digitalTube_6.drawStr((6,0,'I'))
    time.sleep(1)
    digitalTube_6.drawStr((2,0,'AM'))
    time.sleep(1)
    digitalTube_6.drawBitMap((0x50,0x20,0x50,0x0,0x78,0x14,0x78,0x0,0x78,0x10,0x8,0x70,0x8,0x70,0x8,0x70))
    time.sleep(3)

Hiwonder.startMain(start_main)
