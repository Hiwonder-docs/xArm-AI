import Hiwonder
import time
from Hiwonder import LSC

# initialize variables
delay_time = 0


LSC.runActionGroup(0,1)




def start_main():
  global delay_time

  delay_time = 0.1
  while True:
    Hiwonder.Neopixel_onboard.setItem(1-1,255,0,0)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(1-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    Hiwonder.Neopixel_onboard.setItem(2-1,0,255,0)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(2-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    Hiwonder.Neopixel_onboard.setItem(3-1,0,0,255)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(3-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    Hiwonder.Neopixel_onboard.setItem(6-1,255,0,0)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(6-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    Hiwonder.Neopixel_onboard.setItem(5-1,0,255,0)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(5-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    Hiwonder.Neopixel_onboard.setItem(4-1,0,0,255)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)
    Hiwonder.Neopixel_onboard.setItem(4-1,0,0,0)
    Hiwonder.Neopixel_onboard.write()
    time.sleep(delay_time)

Hiwonder.startMain(start_main)

