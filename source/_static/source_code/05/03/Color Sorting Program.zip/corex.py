import Hiwonder
import time
import kinematics
from Hiwonder import LSC

# initialize variables
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
colorsensor_4 = Hiwonder.ColorSensor(Hiwonder.Port(4))


def start_main():
  global digitalTube_6
  global colorsensor_4

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  kinematics.ki_move(-18,0,8,-32,1000)
  LSC.moveServo(1,100,500)
  time.sleep(1)
  while True:
    Hiwonder.Neopixel_onboard.fill(0,0,0)
    digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
    if colorsensor_4.readColorName() == 2:
      Hiwonder.Neopixel_onboard.fill(255,0,0)
      digitalTube_6.drawStr((6,0,'R'))
      time.sleep(2)
      LSC.moveServo(1,500,500)
      time.sleep(1)
      kinematics.ki_move(-17,0,20.5,0,800)
      time.sleep(0.8)
      kinematics.ki_move(-19.5,0,2.8,-60,800)
      time.sleep(0.8)
      LSC.moveServo(1,100,500)
      time.sleep(0.8)
      kinematics.ki_move(-17,0,20.5,0,800)
      time.sleep(0.8)
      kinematics.ki_move(-18,0,8,-32,1000)
      time.sleep(1)
    else:
      if colorsensor_4.readColorName() == 5:
        Hiwonder.Neopixel_onboard.fill(0,255,0)
        digitalTube_6.drawStr((6,0,'G'))
        time.sleep(2)
        LSC.moveServo(1,500,500)
        time.sleep(1)
        kinematics.ki_move(-17,0,20.5,0,800)
        time.sleep(0.8)
        kinematics.ki_move(-12,12,20.5,0,800)
        time.sleep(0.8)
        kinematics.ki_move(-14,14,2.9,-59,800)
        time.sleep(0.8)
        LSC.moveServo(1,100,500)
        time.sleep(1)
        kinematics.ki_move(-12,12,20.5,0,800)
        time.sleep(0.8)
        kinematics.ki_move(-17,0,20.5,0,800)
        time.sleep(0.8)
        kinematics.ki_move(-18,0,8,-32,1000)
        time.sleep(1)
      else:
        if colorsensor_4.readColorName() == 7:
          Hiwonder.Neopixel_onboard.fill(0,0,255)
          digitalTube_6.drawStr((6,0,'B'))
          time.sleep(2)
          LSC.moveServo(1,500,500)
          time.sleep(1)
          kinematics.ki_move(-17,0,20.5,0,800)
          time.sleep(0.8)
          kinematics.ki_move(12,12,20.5,0,1000)
          time.sleep(1)
          kinematics.ki_move(14,14,2.9,-59,800)
          time.sleep(0.8)
          LSC.moveServo(1,100,500)
          time.sleep(1)
          kinematics.ki_move(12,12,20.5,0,1000)
          time.sleep(1)
          kinematics.ki_move(-17,0,20.5,0,1500)
          time.sleep(1.5)
          kinematics.ki_move(-18,0,8,-32,1000)
          time.sleep(1)
        else:
          if colorsensor_4.readColorName() == 4:
            Hiwonder.Neopixel_onboard.fill(255,255,0)
            digitalTube_6.drawStr((6,0,'Y'))
            time.sleep(2)
            LSC.moveServo(1,500,500)
            time.sleep(1)
            kinematics.ki_move(-17,0,20.5,0,800)
            time.sleep(0.8)
            kinematics.ki_move(17,0,20.5,0,1500)
            time.sleep(1)
            kinematics.ki_move(19.5,0,2.8,-60,800)
            time.sleep(0.8)
            LSC.moveServo(1,100,500)
            time.sleep(1)
            kinematics.ki_move(17,0,20.5,0,800)
            time.sleep(0.8)
            kinematics.ki_move(-17,0,20.5,0,1500)
            time.sleep(1)
            kinematics.ki_move(-18,0,8,-32,1000)
            time.sleep(1)

Hiwonder.startMain(start_main)
