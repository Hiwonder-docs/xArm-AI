import Hiwonder
import time
from Hiwonder import LSC
from Hiwonder import Buzzer

# initialize variables
_var_8ddd_79bb = 0
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))


LSC.runActionGroup(0,1)




def start_main():
  global _var_8ddd_79bb
  global i2csonar_3
  global digitalTube_6

  while True:
    _var_8ddd_79bb = round(i2csonar_3.getDistance())
    digitalTube_6.showNum((_var_8ddd_79bb,1))
    if (_var_8ddd_79bb>10):
      Hiwonder.Neopixel_onboard.fill(0,255,0)
      i2csonar_3.setRGB(0,0,255,0)
    else:
      Hiwonder.Neopixel_onboard.fill(255,0,0)
      i2csonar_3.setRGB(0,255,0,0)
      Buzzer.playTone(1976,500,True)
    time.sleep(0.1)

Hiwonder.startMain(start_main)
