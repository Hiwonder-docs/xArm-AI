import Hiwonder
import time
import kinematics

# initialize variables
Z_position = 0
state = 0


def start_main():
  global Z_position
  global state

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  kinematics.ki_move(0,17,20.5,0,1000)
  Z_position = 20.5
  state = 0
  while True:
    if (Hiwonder.Sound_onboard.read()>50):
      if (state==0):
        Z_position+=1
        if (Z_position>25.8):
          Z_position = 25.8
          state = 1
      else:
        Z_position+=-1
        if (Z_position<16.4):
          Z_position = 16.4
          state = 0
      kinematics.ki_move(0,17,Z_position,0,500)

Hiwonder.startMain(start_main)

