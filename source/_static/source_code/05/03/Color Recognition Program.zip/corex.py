import Hiwonder
import time
from Hiwonder import LSC

# initialize variables
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
colorsensor_4 = Hiwonder.ColorSensor(Hiwonder.Port(4))


def start_main():
  global digitalTube_6
  global colorsensor_4

  LSC.runActionGroup(0,1)
  time.sleep(1)
  while True:
    Hiwonder.Neopixel_onboard.fill(0,0,0)
    digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
    if colorsensor_4.readColorName() == 2:
      Hiwonder.Neopixel_onboard.fill(255,0,0)
      digitalTube_6.drawStr((6,0,'R'))
      time.sleep(2)
    else:
      if colorsensor_4.readColorName() == 5:
        Hiwonder.Neopixel_onboard.fill(0,255,0)
        digitalTube_6.drawStr((6,0,'G'))
        time.sleep(2)
      else:
        if colorsensor_4.readColorName() == 7:
          Hiwonder.Neopixel_onboard.fill(0,0,255)
          digitalTube_6.drawStr((6,0,'B'))
          time.sleep(2)
        else:
          if colorsensor_4.readColorName() == 4:
            Hiwonder.Neopixel_onboard.fill(255,255,0)
            digitalTube_6.drawStr((6,0,'Y'))
            time.sleep(2)

Hiwonder.startMain(start_main)
