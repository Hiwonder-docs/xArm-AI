import Hiwonder
import time
from Hiwonder import LSC


def start_main():
  LSC.runActionGroup(0,1)


def on_button_A_clicked():
  if LSC.actionFinish():
    LSC.runActionGroup(3,1)


def on_button_B_clicked():
  if LSC.actionFinish():
    LSC.runActionGroup(2,1)

Hiwonder.startMain(start_main)
Hiwonder.Button_A.Clicked(on_button_A_clicked)
Hiwonder.Button_B.Clicked(on_button_B_clicked)
