import Hiwonder
import time
import kinematics
from Hiwonder import LSC

# initialize variables
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
asr2 = Hiwonder.WonderEcho(Hiwonder.Port(4))


def start_main():
  global digitalTube_6
  global asr2

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  LSC.runActionGroup(0,1)
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  time.sleep(2)
  while True:
    asr2.speak(asr2.ASR_ANNOUNCER, 1)
    time.sleep(2)
    asr2.speak(asr2.ASR_ANNOUNCER, 2)
    time.sleep(2)
    asr2.speak(asr2.ASR_ANNOUNCER, 3)
    time.sleep(2)
    asr2.speak(asr2.ASR_ANNOUNCER, 4)
    time.sleep(2)
    asr2.speak(asr2.ASR_ANNOUNCER, 5)
    time.sleep(2)

Hiwonder.startMain(start_main)
