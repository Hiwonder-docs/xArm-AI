import Hiwonder
import time
import kinematics
from Hiwonder import LSC
from Hiwonder import Buzzer

# initialize variables
Glossary_ID_recognization = 0
count = 0
result_classification_lastround = 0
result_classification_thisround = 0
Glossary_ID_execute = 0
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
asr2 = Hiwonder.WonderEcho(Hiwonder.Port(4))
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))


def start_main():
  global Glossary_ID_recognization
  global count
  global result_classification_lastround
  global result_classification_thisround
  global Glossary_ID_execute
  global digitalTube_6
  global asr2
  global cam
  global i2csonar_3

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  LSC.runActionGroup(0,1)
  Glossary_ID_recognization = 0
  count = 0
  result_classification_lastround = 0
  result_classification_thisround = 0
  Glossary_ID_execute = 0
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  cam.setLed(cam.LED_OFF)
  i2csonar_3.setRGB(0,0x00,0x00,0x00)
  while True:
    if LSC.actionFinish():
      Glossary_ID_recognization = asr2.getResult()
      if ((Glossary_ID_execute==99) or (((Glossary_ID_execute==100) or (Glossary_ID_execute==101)))):
        Glossary_ID_execute = Glossary_ID_recognization
        LSC.runActionGroup(1,1)
    time.sleep(0.1)


def start_main1():
  global Glossary_ID_recognization
  global count
  global result_classification_lastround
  global result_classification_thisround
  global Glossary_ID_execute
  global digitalTube_6
  global asr2
  global cam
  global i2csonar_3

  time.sleep(2)
  while True:
    if LSC.actionFinish():
      cam.updateResult()
      if ((Glossary_ID_execute==99) or (((Glossary_ID_execute==100) or (Glossary_ID_execute==101)))):
        if (Glossary_ID_execute==100):
          cam.switchFunc(cam.Classification)
          result_classification_thisround = cam.getClMaxProbId()
          if (result_classification_thisround==result_classification_lastround):
            count+=1
            if (count>5):
              count = 0
              if ((result_classification_thisround>=2) and (result_classification_thisround<=4)):
                asr2.speak(asr2.ASR_ANNOUNCER, 3)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(6,1)
                time.sleep(5.2)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
              if ((result_classification_thisround>=5) and (result_classification_thisround<=7)):
                asr2.speak(asr2.ASR_ANNOUNCER, 1)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(7,1)
                time.sleep(5.4)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
              if ((result_classification_thisround>=8) and (result_classification_thisround<=10)):
                asr2.speak(asr2.ASR_ANNOUNCER, 2)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(8,1)
                time.sleep(5.4)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
              if ((result_classification_thisround>=11) and (result_classification_thisround<=13)):
                asr2.speak(asr2.ASR_ANNOUNCER, 4)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(9,1)
                time.sleep(5.2)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
          else:
            result_classification_lastround = result_classification_thisround
            count = 0
        else:
          if (Glossary_ID_execute==101):
            cam.switchFunc(cam.ColorDetect)
            if cam.isColorOfIdDetected(1):
              time.sleep(0.2)
              cam.updateResult()
              if cam.isColorOfIdDetected(1):
                Hiwonder.Neopixel_onboard.fill(255,0,0)
                Buzzer.playTone(1976,500,False)
                time.sleep(1)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(6,1)
                time.sleep(5.2)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
            else:
              if cam.isColorOfIdDetected(2):
                time.sleep(0.2)
                cam.updateResult()
                if cam.isColorOfIdDetected(2):
                  Hiwonder.Neopixel_onboard.fill(0,255,0)
                  Buzzer.playTone(1976,500,False)
                  time.sleep(1)
                  kinematics.ki_move(0,17,1.2,-71,800)
                  time.sleep(0.8)
                  LSC.moveServo(1,500,400)
                  time.sleep(0.8)
                  kinematics.ki_move(0,17,20.5,0,800)
                  time.sleep(0.8)
                  LSC.runActionGroup(7,1)
                  time.sleep(5.4)
                  LSC.runActionGroup(1,1)
                  time.sleep(0.8)
              else:
                if cam.isColorOfIdDetected(3):
                  time.sleep(0.2)
                  cam.updateResult()
                  if cam.isColorOfIdDetected(3):
                    Hiwonder.Neopixel_onboard.fill(0,0,255)
                    Buzzer.playTone(1976,500,False)
                    time.sleep(1)
                    kinematics.ki_move(0,17,1.2,-71,800)
                    time.sleep(0.8)
                    LSC.moveServo(1,500,400)
                    time.sleep(0.8)
                    kinematics.ki_move(0,17,20.5,0,800)
                    time.sleep(0.8)
                    LSC.runActionGroup(8,1)
                    time.sleep(5.4)
                    LSC.runActionGroup(1,1)
                    time.sleep(0.8)
                else:
                  if cam.isColorOfIdDetected(4):
                    time.sleep(0.2)
                    cam.updateResult()
                    if cam.isColorOfIdDetected(4):
                      Hiwonder.Neopixel_onboard.fill(0xfd,0xd0,0x00)
                      Buzzer.playTone(1976,500,False)
                      time.sleep(1)
                      kinematics.ki_move(0,17,1.2,-71,800)
                      time.sleep(0.8)
                      LSC.moveServo(1,500,400)
                      time.sleep(0.8)
                      kinematics.ki_move(0,17,20.5,0,800)
                      time.sleep(0.8)
                      LSC.runActionGroup(9,1)
                      time.sleep(5.2)
                      LSC.runActionGroup(1,1)
                      time.sleep(0.8)
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)
          else:
            cam.switchFunc(cam.AprilTag)
            if cam.isTagOfIdDetected(1):
              time.sleep(0.2)
              cam.updateResult()
              if cam.isTagOfIdDetected(1):
                digitalTube_6.showNum((1,2))
                Buzzer.playTone(1976,500,False)
                time.sleep(1)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(6,1)
                time.sleep(5.2)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
            else:
              if cam.isTagOfIdDetected(2):
                time.sleep(0.2)
                cam.updateResult()
                if cam.isTagOfIdDetected(2):
                  digitalTube_6.showNum((2,2))
                  Buzzer.playTone(1976,500,False)
                  time.sleep(1)
                  kinematics.ki_move(0,17,1.2,-71,800)
                  time.sleep(0.8)
                  LSC.moveServo(1,500,400)
                  time.sleep(0.8)
                  kinematics.ki_move(0,17,20.5,0,800)
                  time.sleep(0.8)
                  LSC.runActionGroup(7,1)
                  time.sleep(5.4)
                  LSC.runActionGroup(1,1)
                  time.sleep(0.8)
              else:
                if cam.isTagOfIdDetected(3):
                  time.sleep(0.2)
                  cam.updateResult()
                  if cam.isTagOfIdDetected(3):
                    digitalTube_6.showNum((3,2))
                    Buzzer.playTone(1976,500,False)
                    time.sleep(1)
                    kinematics.ki_move(0,17,1.2,-71,800)
                    time.sleep(0.8)
                    LSC.moveServo(1,500,400)
                    time.sleep(0.8)
                    kinematics.ki_move(0,17,20.5,0,800)
                    time.sleep(0.8)
                    LSC.runActionGroup(8,1)
                    time.sleep(5.4)
                    LSC.runActionGroup(1,1)
                    time.sleep(0.8)
                else:
                  if cam.isTagOfIdDetected(4):
                    time.sleep(0.2)
                    cam.updateResult()
                    if cam.isTagOfIdDetected(4):
                      digitalTube_6.showNum((4,2))
                      Buzzer.playTone(1976,500,False)
                      time.sleep(1)
                      kinematics.ki_move(0,17,1.2,-71,800)
                      time.sleep(0.8)
                      LSC.moveServo(1,500,400)
                      time.sleep(0.8)
                      kinematics.ki_move(0,17,20.5,0,800)
                      time.sleep(0.8)
                      LSC.runActionGroup(9,1)
                      time.sleep(5.2)
                      LSC.runActionGroup(1,1)
                      time.sleep(0.8)
            digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
    time.sleep(0.1)

Hiwonder.startMain(start_main)
Hiwonder.startMain(start_main1)
