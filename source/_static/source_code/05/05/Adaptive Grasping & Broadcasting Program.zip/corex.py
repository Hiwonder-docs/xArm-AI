import Hiwonder
import time
from Hiwonder import Buzzer
import kinematics
from Hiwonder import LSC

# initialize variables
measure_switch = 0
hyperdistance_Voice_switch = 0
distance = 0
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
distance_pinchable_max = 0
distance_pinchable_min = 0
count = 0
Object_size_waitforclamp = 0
length = 0
distance_this_round = 0
distance_last_round = 0
asr2 = Hiwonder.WonderEcho(Hiwonder.Port(4))


def start_main():
  global measure_switch
  global hyperdistance_Voice_switch
  global distance
  global i2csonar_3
  global digitalTube_6
  global distance_pinchable_max
  global distance_pinchable_min
  global count
  global Object_size_waitforclamp
  global length
  global distance_this_round
  global distance_last_round
  global asr2

  measure_switch = 1
  hyperdistance_Voice_switch = 0
  while True:
    if (measure_switch==1):
      distance = i2csonar_3.getDistance()
      digitalTube_6.showNum((distance,1))
      if ((distance<distance_pinchable_max) and (distance>distance_pinchable_min)):
        i2csonar_3.setRGB(0,0,255,0)
        Hiwonder.Neopixel_onboard.fill(0,255,0)
      else:
        if (distance>=distance_pinchable_max):
          if not (distance==500):
            i2csonar_3.setRGB(0,0,0,255)
            Hiwonder.Neopixel_onboard.fill(0,0,255)
        else:
          i2csonar_3.setRGB(0,255,0,0)
          Hiwonder.Neopixel_onboard.fill(255,0,0)
          Buzzer.playTone(1976,500,True)
    time.sleep(0.5)


def start_main1():
  global measure_switch
  global hyperdistance_Voice_switch
  global distance
  global i2csonar_3
  global digitalTube_6
  global distance_pinchable_max
  global distance_pinchable_min
  global count
  global Object_size_waitforclamp
  global length
  global distance_this_round
  global distance_last_round
  global asr2

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  kinematics.ki_move(0,17,20.5,0,500)
  LSC.moveServo(1,100,500)
  count = 0
  Object_size_waitforclamp = 3.93
  length = 8.5
  distance_pinchable_min = 5
  distance_pinchable_max = 17
  distance_this_round = 0
  distance_last_round = 0
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  i2csonar_3.setRGB(0,0,0,255)
  time.sleep(1)
  while True:
    distance_this_round = distance
    if (distance_this_round<distance_pinchable_max):
      hyperdistance_Voice_switch = 0
    if (distance_last_round==distance_this_round):
      measure_switch = 0
      if ((distance_this_round<distance_pinchable_max) and (distance_this_round>distance_pinchable_min)):
        time.sleep(1)
        asr2.speak(asr2.ASR_ANNOUNCER, 16)
        kinematics.ki_move_adapt(0,(distance_this_round+((length+(Object_size_waitforclamp/2)))),2,-90,90,2000)
        time.sleep(0.2)
        LSC.moveServo(1,500,500)
        time.sleep(0.8)
        kinematics.ki_move(0,17,20.5,0,1400)
        time.sleep(0.4)
        LSC.runActionGroup(8,1)
        time.sleep(4.8)
        asr2.speak(asr2.ASR_ANNOUNCER, 18)
        time.sleep(1)
      else:
        if (distance_this_round>distance_pinchable_max):
          if (distance_this_round<40):
            if (hyperdistance_Voice_switch==0):
              hyperdistance_Voice_switch = 1
              asr2.speak(asr2.ASR_ANNOUNCER, 17)
              time.sleep(3.5)
        else:
          time.sleep(0.5)
      measure_switch = 1
    time.sleep(0.8)
    distance_last_round = distance_this_round

Hiwonder.startMain(start_main)
Hiwonder.startMain(start_main1)
