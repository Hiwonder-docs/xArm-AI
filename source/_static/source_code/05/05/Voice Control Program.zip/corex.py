import Hiwonder
import time
import kinematics
from Hiwonder import LSC

# initialize variables
ID_Identify = 0
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))
asr2 = Hiwonder.WonderEcho(Hiwonder.Port(4))


def start_main():
  global ID_Identify
  global digitalTube_6
  global asr2

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  LSC.runActionGroup(0,1)
  ID_Identify = 0
  digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  while True:
    if LSC.actionFinish():
      Hiwonder.Neopixel_onboard.fill(0,0,0)
      digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
      ID_Identify = asr2.getResult()
      if (ID_Identify==105):
        digitalTube_6.drawStr((7,0,'R'))
        Hiwonder.Neopixel_onboard.fill(255,0,0)
        time.sleep(1)
        LSC.runActionGroup(2,1)
      else:
        if (ID_Identify==106):
          digitalTube_6.drawStr((7,0,'G'))
          Hiwonder.Neopixel_onboard.fill(0,255,0)
          time.sleep(1)
          LSC.runActionGroup(3,1)
        else:
          if (ID_Identify==107):
            digitalTube_6.drawStr((7,0,'B'))
            Hiwonder.Neopixel_onboard.fill(0,0,255)
            time.sleep(1)
            LSC.runActionGroup(4,1)
          else:
            if (ID_Identify==124):
              digitalTube_6.drawStr((7,0,'Y'))
              Hiwonder.Neopixel_onboard.fill(0xfd,0xd0,0x00)
              time.sleep(1)
              LSC.runActionGroup(5,1)
    else:
      ID_Identify = asr2.getResult()

Hiwonder.startMain(start_main)
