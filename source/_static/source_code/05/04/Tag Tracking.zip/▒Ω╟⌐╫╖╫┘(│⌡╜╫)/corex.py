import Hiwonder
import time
import kinematics
import math
from Hiwonder import LSC

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
X = 0
Z = 0
Target_area = 0
dx = 0
dz = 0


def start_main():
  global cam
  global X
  global Z
  global Target_area
  global dx
  global dz

  Hiwonder.disableLowPowerAlarm()
  cam.switchFunc(cam.AprilTag)
  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  kinematics.ki_move(0,15,20,0,1500)
  X = 500
  Z = 310
  Target_area = 0
  while True:
    cam.updateResult()
    if cam.isTagOfIdDetected(1):
      Target_area = (cam.getDataOfTagIdIndex(1,1)[2]*cam.getDataOfTagIdIndex(1,1)[3])
      if (Target_area>1000):
        dx = (cam.getDataOfTagIdIndex(1,1)[0]-160)
        dz = (cam.getDataOfTagIdIndex(1,1)[1]-120)
        if (math.fabs(dx)>10):
          X+=round((dx/-8))
          if (X>1000):
            X = 1000
          if (X<0):
            X = 0
          LSC.moveServo(6,X,20)
        if (math.fabs(dz)>5):
          Z+=round((dz/-10))
          if (Z>1000):
            Z = 1000
          if (Z<0):
            Z = 0
          LSC.moveServo(3,Z,20)
    else:
      time.sleep(0.01)

Hiwonder.startMain(start_main)
