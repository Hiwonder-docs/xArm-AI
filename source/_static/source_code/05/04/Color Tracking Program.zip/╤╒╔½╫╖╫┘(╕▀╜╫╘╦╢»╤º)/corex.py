import Hiwonder
import time
import kinematics
import math

'''
现象描述：上电后机械臂默认转动至初始姿态，识别到目标后开始追踪，目标丢失后机械臂静止，视觉模块继续工作等待下一次识别到目标
备注：标签追踪与颜色追踪的现象与实现逻辑基本一致     
'''

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
X = 0             #机械臂末端控制器(机械爪)在机械臂坐标系X轴坐标（理论计算值）
X_execute = 0     #机械臂末端控制器(机械爪)在机械臂坐标系X轴坐标（实际执行值）
Y = 0
Y_execute = 0
Z = 0
Z_execute = 0
radius = 0        #机械臂追踪轨迹为半圆弧，该值为轨迹半径
                  #机械臂在初始姿态时，朝正前方(Y+方向)，末端坐标：(0,17,20.5),保持该姿态(俯仰角=0°)以圆形轨迹进行追踪(X-Y面上)，故取当前Y轴作为半径
                  #也可自行尝试取其他值，但某些取值在逆运动学求解下不一定有解

Target_area = 0   #色块在视觉模块画面中的面积，该值与物块距离视觉模块（所在的机械爪）的距离远近成正比，以此值确保色块不会放置的过远
running_state = 0 #运行状态，=0：线程1工作，分析视觉模块数据  =1：线程2工作，开始控制机械臂运动
dx = 0            #在视觉模块二维画面坐标系中，目标识别框中心点坐标距离画面中心点坐标X轴差值
dz = 0


def start_main():  #线程1：识别目标，计算目标在画面距中心偏移量，换算对应机械臂末端控制器(机械爪)在机械臂坐标系X、Z轴坐标偏移量
  global cam
  global X
  global X_execute
  global Y
  global Y_execute
  global Z
  global Z_execute
  global radius
  global Target_area
  global running_state
  global dx
  global dz

  Hiwonder.disableLowPowerAlarm()
  cam.switchFunc(cam.ColorDetect)
  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  kinematics.ki_move(0,17,20.5,0,500)
  X = 0             #X、Y、Z实际执行值在初始化时，默认取与初始姿态时相同的坐标值，否则机械臂会立刻转动到此处X、Y、Z实际执行值指定的坐标
  X_execute = 0
  Y = 17
  Y_execute = 17
  Z = 20.5
  Z_execute = 20.5
  radius = 17
  Target_area = 0
  running_state = 0 #默认先进入运行状态0，先获取识别数据进行运算
  while True:
    cam.updateResult()
    if cam.isColorOfIdDetected(1):
      Target_area = (cam.getColorOfId(1)[2]*cam.getColorOfId(1)[3])
      if (Target_area>500):                         #大于此阈值才开始计算，此时目标距离足够近，识别效果好，同时避免误识别
        dx = (cam.getColorOfId(1)[0]-160)           #视觉模块二维画面坐标系中，画面中心点坐标：(160,120)
        dz = (cam.getColorOfId(1)[1]-120)           #二维画面坐标系X轴<-->机械臂三维坐标系X-Y面  二维画面坐标系Y轴<-->机械臂三维坐标系Z轴
        if (math.fabs(dz)>5):                       #二维画面坐标偏差值过小则机械臂无需移动
          Z = (Z+(dz/-1200))                        #将二维画面坐标偏差值 换算为 机械臂三维坐标偏差值(dz/-1200)
          if (Z>25.8):
            Z = 25.8
          if (Z<16.4):                              #经实测，Z在16.4--25.8内取值，X在-17--17取值(Y与X有约束关系，不是独立变量)，逆运动学计算均有解
            Z = 16.4
          Z_execute = Z
        if (math.fabs(dx)>10):
          X = (X+(dx/1100))
          if (X>17):
            X = 17
          if (X<-17):
            X = -17
          Y = math.sqrt(((radius*radius)-(X*X)))   #因为机械臂在X-Y平面上以圆形轨迹追踪，故X^2 + Y^2 =r^2
          X_execute = X
          Y_execute = Y
        running_state = 1                          #线程2生效，X、Y、Z的实际执行量被采用


def start_main1():  #线程2：接收线程1计算得到的运动参数，使用逆运动学控制机械臂运动
  global cam
  global X
  global X_execute
  global Y
  global Y_execute
  global Z
  global Z_execute
  global radius
  global Target_area
  global running_state
  global dx
  global dz

  while True:
    if (running_state>0):
      kinematics.ki_move(X_execute,Y_execute,Z_execute,0,500)
      running_state = 0

Hiwonder.startMain(start_main)
Hiwonder.startMain(start_main1)
