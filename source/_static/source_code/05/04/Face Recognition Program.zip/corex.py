import Hiwonder
import time
from Hiwonder import LSC

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
digitalTube_6 = Hiwonder.Digitaltube(Hiwonder.Port(6))


def start_main():
  global cam
  global digitalTube_6

  Hiwonder.disableLowPowerAlarm()
  cam.switchFunc(cam.FaceDetect)
  LSC.runActionGroup(0,1)
  while True:
    cam.updateResult()
    digitalTube_6.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
    if cam.isAnyFaceDetected():
      digitalTube_6.drawBitMap((0x7f,0x8,0x7f,0x0,0x7c,0x54,0x5c,0x0,0x7c,0x40,0x0,0x7c,0x40,0x38,0x44,0x38))
      LSC.moveServo(1,500,800)
      time.sleep(1)
      LSC.moveServo(1,100,800)
      time.sleep(1)

Hiwonder.startMain(start_main)
