import Hiwonder
import time
import kinematics
from Hiwonder import LSC

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
digitalTube_8 = Hiwonder.Digitaltube(Hiwonder.Port(6))
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))
count = 0
result_last = 0
result_now = 0


def start_main():
  global cam
  global digitalTube_8
  global i2csonar_4
  global count
  global result_last
  global result_now

  Hiwonder.disableLowPowerAlarm()
  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  cam.setLed(cam.LED_ON)
  cam.switchFunc(cam.Classification)
  digitalTube_8.setBrightness(8)
  digitalTube_8.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
  i2csonar_4.setRGB(0,0x00,0x00,0x00)
  LSC.runActionGroup(1,1)
  count = 0
  result_last = 0
  while True:
    cam.updateResult()
    digitalTube_8.drawBitMap((0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0))
    result_now = cam.getClMaxProbId()
    if (result_now==result_last):
      count+=1
    else:
      count = 0
      result_last = result_now
    if (count>=5):
      count = 0
      if ((result_now>=2) and (result_now<=4)):
        Hiwonder.Neopixel_onboard.fill(255,0,0)
        digitalTube_8.drawBitMap((0x0,0x0,0x0,0x81,0xc3,0x66,0x3c,0x18,0x3c,0x66,0xc3,0x81,0x0,0x0,0x0,0x0))
        time.sleep(0.5)
        kinematics.ki_move(0,17,1.2,-71,800)
        time.sleep(1)
        LSC.moveServo(1,500,500)
        time.sleep(0.8)
        kinematics.ki_move(0,17,20.5,0,800)
        time.sleep(0.8)
        LSC.runActionGroup(6,1)
        time.sleep(5)
        LSC.runActionGroup(1,1)
        time.sleep(1)
      else:
        if ((result_now>=5) and (result_now<=7)):
          Hiwonder.Neopixel_onboard.fill(0,0,255)
          digitalTube_8.drawBitMap((0x0,0x0,0x0,0x8,0xc,0x4a,0x89,0xff,0x9,0xa,0xc,0x8,0x0,0x0,0x0,0x0))
          time.sleep(0.5)
          kinematics.ki_move(0,17,1.2,-71,800)
          time.sleep(1)
          LSC.moveServo(1,500,500)
          time.sleep(0.8)
          kinematics.ki_move(0,17,20.5,0,800)
          time.sleep(0.8)
          LSC.runActionGroup(7,1)
          time.sleep(5)
          LSC.runActionGroup(1,1)
          time.sleep(1)
        else:
          if ((result_now>=8) and (result_now<=10)):
            Hiwonder.Neopixel_onboard.fill(0,255,0)
            digitalTube_8.drawBitMap((0x18,0x3c,0x7a,0xff,0xff,0x18,0x3c,0x5a,0x99,0x3c,0x5a,0x18,0x18,0x7e,0x3c,0x18))
            time.sleep(0.5)
            kinematics.ki_move(0,17,1.2,-71,800)
            time.sleep(1)
            LSC.moveServo(1,500,500)
            time.sleep(0.8)
            kinematics.ki_move(0,17,20.5,0,800)
            time.sleep(0.8)
            LSC.runActionGroup(8,1)
            time.sleep(5)
            LSC.runActionGroup(1,1)
            time.sleep(1)
          else:
            if ((result_now>=11) and (result_now<=13)):
              Hiwonder.Neopixel_onboard.fill(30,30,30)
              digitalTube_8.drawBitMap((0x7c,0x76,0x73,0x73,0x71,0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x50,0x50,0x50,0x70))
              time.sleep(0.5)
              kinematics.ki_move(0,17,1.2,-71,800)
              time.sleep(1)
              LSC.moveServo(1,500,500)
              time.sleep(0.8)
              kinematics.ki_move(0,17,20.5,0,800)
              time.sleep(0.8)
              LSC.runActionGroup(9,1)
              time.sleep(5)
              LSC.runActionGroup(1,1)
              time.sleep(1)
            else:
              Hiwonder.Neopixel_onboard.clear()
              time.sleep(0.01)
              time.sleep(0.5)
    time.sleep(0.1)

Hiwonder.startMain(start_main)

