import Hiwonder
import time
from Hiwonder import LSC
import math

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
_X = 0
_Z = 0
_var_53d8_5316_503c = 0
_face_index = 0
_id = 0
_dx = 0
_dz = 0


def start_main():
  global cam
  global _X
  global _Z
  global _var_53d8_5316_503c
  global _face_index
  global _id
  global _dx
  global _dz

  Hiwonder.disableLowPowerAlarm()
  cam.setLed(cam.LED_OFF)
  cam.switchFunc(cam.FaceDetect)
  LSC.runActionGroup(0,1)
  _X = 500
  _Z = 310
  _var_53d8_5316_503c = 20
  _face_index = 1
  time.sleep(1)
  while True:
    cam.updateResult()
    if cam.isAnyFaceDetected():
      if cam.isAnyLearnedFaceRec():
        while not (_face_index>5):
          if cam.isFaceOfIdRec(_face_index):
            _id = _face_index
            break
          _face_index+=1
        _dx = (cam.getFaceOfId(_face_index)[0]-160)
        _dz = (cam.getFaceOfId(_face_index)[1]-120)
      if cam.isAnyUnlearnedFaceDetected():
        _dx = (cam.getUnlearnedFaceOfIndex(1)[0]-160)
        _dz = (cam.getUnlearnedFaceOfIndex(1)[1]-120)
      if (math.fabs(_dx)>10):
        _X+=round((_dx/-8))
        if (_X>1000):
          _X = 1000
        if (_X<0):
          _X = 0
        LSC.moveServo(6,_X,200)
      if (math.fabs(_dz)>5):
        _Z+=round((_dz/-10))
        if (_Z>1000):
          _Z = 1000
        if (_Z<0):
          _Z = 0
        LSC.moveServo(3,_Z,200)
      time.sleep(0.1)
    else:
      _face_index = 1
      LSC.moveServo(3,310,1000)
      _X+=_var_53d8_5316_503c
      if (_X>800):
        _X = 800
        _var_53d8_5316_503c = (0-_var_53d8_5316_503c)
      if (_X<200):
        _X = 200
        _var_53d8_5316_503c = 20
      LSC.moveServo(6,_X,200)
      time.sleep(0.12)

Hiwonder.startMain(start_main)
