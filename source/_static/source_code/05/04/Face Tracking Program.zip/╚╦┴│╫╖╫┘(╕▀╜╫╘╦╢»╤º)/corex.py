import Hiwonder
import time
import kinematics
import math

'''
现象描述：1.上电后机械臂默认转动至初始姿态，识别到目标后开始追踪
        2.支持对已学习人脸、未学习人脸的追踪，如果目标已被学习，会匹配对应ID
        3.目标丢失后，机械臂末端保持当前朝向(X、Y值)，回到初始高度(Z=20.5)，以前方180°来回循环转动，搜索目标
备注：与标签追踪、颜色追踪的现象与实现逻辑有区别，请注意区别     
'''

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
X = 0                    #机械臂末端控制器(机械爪)在机械臂坐标系X轴坐标（理论计算值）
Y = 0                    
Z = 0                    
X_delta = 0              #当识别不到人脸时此值生效，控制机械臂末端执行器（机械爪)前端x轴坐标不断变化，从而让机械臂180°旋转，寻找人脸目标
face_index = 0           #视觉模块已学习的人脸ID
X_execute = 0            #机械臂末端控制器(机械爪)在机械臂坐标系X轴坐标（实际执行值）
Y_execute = 0            
Z_execute = 0            
radius = 0               #机械臂追踪轨迹为半圆弧，该值为轨迹半径          
                         #机械臂在初始姿态时，朝正前方(Y+方向)，末端坐标：(0,17,20.5),保持该姿态(俯仰角=0°)以圆形轨迹进行追踪(X-Y面上)，故取当前Y轴作为半径
                         #也可自行尝试取其他值，但某些取值在逆运动学求解下不一定有解
                         
running_state = 0        #运行状态，=0：线程1工作，分析视觉模块数据  =1：线程2工作，开始控制机械臂运动
id = 0                   
dx = 0                   #在视觉模块二维画面坐标系中，目标识别框中心点坐标距离画面中心点坐标X轴差值 
dz = 0                   
Reduction_ratio = 0      #减速比
'''机械臂在x靠近中心的时候，每次运动（x轴坐标改变）对应的运动轨迹偏小；越靠近两侧，单次运动的运动轨迹越大
  为了保证机械臂全程的运动速度基本一致，对于在两侧的运动，需要在单次运动时间的基础上加成此减速比'''
move_time = 0


def start_main():        #线程1：识别目标，计算目标在画面距中心偏移量，换算对应机械臂末端控制器(机械爪)在机械臂坐标系X、Z轴坐标偏移量
  global cam
  global X
  global Y
  global Z
  global X_delta
  global face_index
  global X_execute
  global Y_execute
  global Z_execute
  global radius
  global running_state
  global id
  global dx
  global dz
  global Reduction_ratio
  global move_time

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  Hiwonder.disableLowPowerAlarm()
  cam.setLed(cam.LED_OFF)
  cam.switchFunc(cam.FaceDetect)
  kinematics.ki_move(0,17,20.5,3,500)
  X = 0                #X、Y、Z实际执行值在初始化时，默认取与初始姿态时相同的坐标值，否则机械臂会立刻转动到此处X、Y、Z实际执行值指定的坐标
  Y = 17
  Z = 20.5
  X_delta = 2
  face_index = 1
  X_execute = 0
  Y_execute = 17
  Z_execute = 20.5
  radius = 17
  running_state = 0   #默认先进入运行状态0，先获取识别数据进行运算
  time.sleep(1)
  while True:
    if (running_state==0):   #运动状态为1时，机械臂在线程2的控制下运动，在此期间无需再对视觉模块数据进行解算，释放资源
      cam.updateResult()
	  
      if cam.isAnyFaceDetected():                      #识别到人脸
	  
        if cam.isAnyLearnedFaceRec():                  #该人脸已被学习
          while not (face_index>5):                    #对已学习的人脸进行ID匹配
            if cam.isFaceOfIdRec(face_index):
              id = face_index
              break
            face_index+=1
          dx = (cam.getFaceOfId(face_index)[0]-160)    #视觉模块二维画面坐标系中，画面中心点坐标：(160,120)
          dz = (cam.getFaceOfId(face_index)[1]-120)    #二维画面坐标系X轴<-->机械臂三维坐标系X-Y面  二维画面坐标系Y轴<-->机械臂三维坐标系Z轴
		  
        if cam.isAnyUnlearnedFaceDetected():           #该人脸未被学习
          dx = (cam.getUnlearnedFaceOfIndex(1)[0]-160)
          dz = (cam.getUnlearnedFaceOfIndex(1)[1]-120)
        if (math.fabs(dx)>10):                         #二维画面坐标偏差值过小则机械臂无需移动
          X+=(dx/40)                                   #将二维画面坐标偏差值 换算为 机械臂三维坐标偏差值(dz/-50)
          if (X>17):
            X = 17
          if (X<-17):
            X = -17
          X_execute = X
          Y = math.sqrt(((radius*radius)-(X*X)))
          Y_execute = Y
        if (math.fabs(dz)>5):
          Z+=(dz/-50)                                 
          if (Z>25.4):                                 #经实测，Z在16.4--25.8内取值，X在-17--17取值(Y与X有约束关系，不是独立变量)，逆运动学计算均有解
            Z = 25.4
          if (Z<17.3):
            Z = 17.3
          Z_execute = Z
        running_state = 1
		
      else:      #未识别到人脸
        face_index = 1
        X+=X_delta
        if (X>17):
          X = 17
          X_delta = (0-X_delta)                       #下一轮开始，机械臂开始反方向运动，下同
        if (X<-17):
          X = -17
          X_delta = (0-X_delta)
        Z_execute = 20.5
        X_execute = X
        Y = math.sqrt(((radius*radius)-(X*X)))        #因为机械臂在X-Y平面上以圆形轨迹追踪，故X^2 + Y^2 =r^2
        Y_execute = Y
        running_state = 1                             #线程2生效，X、Y、Z的实际执行量被采用


def start_main1():  #线程2：接收线程1计算得到的运动参数，使用逆运动学控制机械臂运动
  global cam
  global X
  global Y
  global Z
  global X_delta
  global face_index
  global X_execute
  global Y_execute
  global Z_execute
  global radius
  global running_state
  global id
  global dx
  global dz
  global Reduction_ratio
  global move_time

  Reduction_ratio = 1.75
  move_time = 700
  while True:
    if (running_state==1):
      if (math.fabs(X_execute)>14):     #|x|>14--此时机械臂在两侧区域，实测单次的转动速度（运动轨迹长度）提升至在中间区域的1.5至2倍
        move_time = math.floor((700*Reduction_ratio))
      else:                             #|x|<=14--此时机械臂在中心区域
        move_time = 700
      kinematics.ki_move(X_execute,Y_execute,Z_execute,0,move_time)
      running_state = 0

Hiwonder.startMain(start_main)
Hiwonder.startMain(start_main1)
