import Hiwonder
import time
import kinematics
from Hiwonder import LSC
from Hiwonder import Buzzer

# initialize variables
i2csonar_3 = Hiwonder.I2CSonar(Hiwonder.Port(4))
cam = Hiwonder.WonderCam(Hiwonder.Port(4))
Target_area = 0 
#标签物块在视觉模块画面中的面积，该值与物块距离视觉模块（所在的机械爪）的距离远近成正比，以此值确保物块不会放置的过远


def start_main():
  global i2csonar_3
  global cam
  global Target_area

  kinematics.set_link_length(6.9,9.5,9.5,16.9)
  LSC.moveServo(1,100,500)
  i2csonar_3.setRGB(0,0x00,0x00,0x00)
  cam.setLed(cam.LED_OFF)
  cam.switchFunc(cam.AprilTag)
  LSC.runActionGroup(1,1)
  Target_area = 0
  while True:
    cam.updateResult()
    
    if cam.isTagOfIdDetected(1):
      time.sleep(0.2)
      cam.updateResult()
      if cam.isTagOfIdDetected(1):
        Target_area = (cam.getDataOfTagIdIndex(1,1)[2]*cam.getDataOfTagIdIndex(1,1)[3])
        if (Target_area>1000):
          Hiwonder.Neopixel_onboard.fill(255,0,0)
          Buzzer.playTone(1976,500,True)
          time.sleep(1.5)
          kinematics.ki_move(0,17,1.2,-71,800)
          time.sleep(0.8)
          LSC.moveServo(1,500,400)
          time.sleep(0.8)
          kinematics.ki_move(0,17,20.5,0,800)
          time.sleep(0.8)
          LSC.runActionGroup(6,1)
          time.sleep(4.8)
          LSC.runActionGroup(1,1)
          time.sleep(0.8)
        else:
          Hiwonder.Neopixel_onboard.clear()
          time.sleep(0.01)
    else:
      if cam.isTagOfIdDetected(2):
        time.sleep(0.2)
        cam.updateResult()
        if cam.isTagOfIdDetected(2):
          Target_area = (cam.getDataOfTagIdIndex(2,1)[2]*cam.getDataOfTagIdIndex(2,1)[3])
          if (Target_area>1000):
            Hiwonder.Neopixel_onboard.fill(0,255,0)
            Buzzer.playTone(1976,500,True)
            time.sleep(1.5)
            kinematics.ki_move(0,17,1.2,-71,800)
            time.sleep(0.8)
            LSC.moveServo(1,500,400)
            time.sleep(0.8)
            kinematics.ki_move(0,17,20.5,0,800)
            time.sleep(0.8)
            LSC.runActionGroup(7,1)
            time.sleep(4.8)
            LSC.runActionGroup(1,1)
            time.sleep(0.8)
          else:
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)
      else:
        if cam.isTagOfIdDetected(3):
          time.sleep(0.2)
          cam.updateResult()
          if cam.isTagOfIdDetected(3):
            Target_area = (cam.getDataOfTagIdIndex(3,1)[2]*cam.getDataOfTagIdIndex(3,1)[3])
            if (Target_area>1000):
              Hiwonder.Neopixel_onboard.fill(0,0,255)
              Buzzer.playTone(1976,500,True)
              time.sleep(1.5)
              kinematics.ki_move(0,17,1.2,-71,800)
              time.sleep(0.8)
              LSC.moveServo(1,500,400)
              time.sleep(0.8)
              kinematics.ki_move(0,17,20.5,0,800)
              time.sleep(0.8)
              LSC.runActionGroup(8,1)
              time.sleep(4.8)
              LSC.runActionGroup(1,1)
              time.sleep(0.8)
            else:
              Hiwonder.Neopixel_onboard.clear()
              time.sleep(0.01)
        else:
          if cam.isTagOfIdDetected(4):
            time.sleep(0.2)
            cam.updateResult()
            if cam.isTagOfIdDetected(4):
              Target_area = (cam.getDataOfTagIdIndex(4,1)[2]*cam.getDataOfTagIdIndex(4,1)[3])
              if (Target_area>1000):
                Hiwonder.Neopixel_onboard.fill(255,255,0)
                Buzzer.playTone(1976,500,True)
                time.sleep(1.5)
                kinematics.ki_move(0,17,1.2,-71,800)
                time.sleep(0.8)
                LSC.moveServo(1,500,400)
                time.sleep(0.8)
                kinematics.ki_move(0,17,20.5,0,800)
                time.sleep(0.8)
                LSC.runActionGroup(9,1)
                time.sleep(4.8)
                LSC.runActionGroup(1,1)
                time.sleep(0.8)
              else:
                Hiwonder.Neopixel_onboard.clear()
                time.sleep(0.01)
          else:
            Hiwonder.Neopixel_onboard.clear()
            time.sleep(0.01)

Hiwonder.startMain(start_main)

